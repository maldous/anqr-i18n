
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/qr.ts
import { createCanvas, loadImage } from "@napi-rs/canvas";

// vendor/lib/qrcode-generator/qrcode.mjs
var qrcode = function(typeNumber, errorCorrectionLevel) {
  const PAD0 = 236;
  const PAD1 = 17;
  let _typeNumber = typeNumber;
  const _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
  let _modules = null;
  let _moduleCount = 0;
  let _dataCache = null;
  const _dataList = [];
  const _this = {};
  const makeImpl = function(test, maskPattern) {
    _moduleCount = _typeNumber * 4 + 17;
    _modules = (function(moduleCount) {
      const modules = new Array(moduleCount);
      for (let row = 0; row < moduleCount; row += 1) {
        modules[row] = new Array(moduleCount);
        for (let col = 0; col < moduleCount; col += 1) {
          modules[row][col] = null;
        }
      }
      return modules;
    })(_moduleCount);
    setupPositionProbePattern(0, 0);
    setupPositionProbePattern(_moduleCount - 7, 0);
    setupPositionProbePattern(0, _moduleCount - 7);
    setupPositionAdjustPattern();
    setupTimingPattern();
    setupTypeInfo(test, maskPattern);
    if (_typeNumber >= 7) {
      setupTypeNumber(test);
    }
    if (_dataCache == null) {
      _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
    }
    mapData(_dataCache, maskPattern);
  };
  const setupPositionProbePattern = function(row, col) {
    for (let r = -1; r <= 7; r += 1) {
      if (row + r <= -1 || _moduleCount <= row + r) continue;
      for (let c = -1; c <= 7; c += 1) {
        if (col + c <= -1 || _moduleCount <= col + c) continue;
        if (0 <= r && r <= 6 && (c == 0 || c == 6) || 0 <= c && c <= 6 && (r == 0 || r == 6) || 2 <= r && r <= 4 && 2 <= c && c <= 4) {
          _modules[row + r][col + c] = true;
        } else {
          _modules[row + r][col + c] = false;
        }
      }
    }
  };
  const getBestMaskPattern = function() {
    let minLostPoint = 0;
    let pattern = 0;
    for (let i = 0; i < 8; i += 1) {
      makeImpl(true, i);
      const lostPoint = QRUtil.getLostPoint(_this);
      if (i == 0 || minLostPoint > lostPoint) {
        minLostPoint = lostPoint;
        pattern = i;
      }
    }
    return pattern;
  };
  const setupTimingPattern = function() {
    for (let r = 8; r < _moduleCount - 8; r += 1) {
      if (_modules[r][6] != null) {
        continue;
      }
      _modules[r][6] = r % 2 == 0;
    }
    for (let c = 8; c < _moduleCount - 8; c += 1) {
      if (_modules[6][c] != null) {
        continue;
      }
      _modules[6][c] = c % 2 == 0;
    }
  };
  const setupPositionAdjustPattern = function() {
    const pos = QRUtil.getPatternPosition(_typeNumber);
    for (let i = 0; i < pos.length; i += 1) {
      for (let j = 0; j < pos.length; j += 1) {
        const row = pos[i];
        const col = pos[j];
        if (_modules[row][col] != null) {
          continue;
        }
        for (let r = -2; r <= 2; r += 1) {
          for (let c = -2; c <= 2; c += 1) {
            if (r == -2 || r == 2 || c == -2 || c == 2 || r == 0 && c == 0) {
              _modules[row + r][col + c] = true;
            } else {
              _modules[row + r][col + c] = false;
            }
          }
        }
      }
    }
  };
  const setupTypeNumber = function(test) {
    const bits = QRUtil.getBCHTypeNumber(_typeNumber);
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && (bits >> i & 1) == 1;
      _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
    }
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && (bits >> i & 1) == 1;
      _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
    }
  };
  const setupTypeInfo = function(test, maskPattern) {
    const data = _errorCorrectionLevel << 3 | maskPattern;
    const bits = QRUtil.getBCHTypeInfo(data);
    for (let i = 0; i < 15; i += 1) {
      const mod = !test && (bits >> i & 1) == 1;
      if (i < 6) {
        _modules[i][8] = mod;
      } else if (i < 8) {
        _modules[i + 1][8] = mod;
      } else {
        _modules[_moduleCount - 15 + i][8] = mod;
      }
    }
    for (let i = 0; i < 15; i += 1) {
      const mod = !test && (bits >> i & 1) == 1;
      if (i < 8) {
        _modules[8][_moduleCount - i - 1] = mod;
      } else if (i < 9) {
        _modules[8][15 - i - 1 + 1] = mod;
      } else {
        _modules[8][15 - i - 1] = mod;
      }
    }
    _modules[_moduleCount - 8][8] = !test;
  };
  const mapData = function(data, maskPattern) {
    let inc = -1;
    let row = _moduleCount - 1;
    let bitIndex = 7;
    let byteIndex = 0;
    const maskFunc = QRUtil.getMaskFunction(maskPattern);
    for (let col = _moduleCount - 1; col > 0; col -= 2) {
      if (col == 6) col -= 1;
      while (true) {
        for (let c = 0; c < 2; c += 1) {
          if (_modules[row][col - c] == null) {
            let dark = false;
            if (byteIndex < data.length) {
              dark = (data[byteIndex] >>> bitIndex & 1) == 1;
            }
            const mask = maskFunc(row, col - c);
            if (mask) {
              dark = !dark;
            }
            _modules[row][col - c] = dark;
            bitIndex -= 1;
            if (bitIndex == -1) {
              byteIndex += 1;
              bitIndex = 7;
            }
          }
        }
        row += inc;
        if (row < 0 || _moduleCount <= row) {
          row -= inc;
          inc = -inc;
          break;
        }
      }
    }
  };
  const createBytes = function(buffer, rsBlocks) {
    let offset = 0;
    let maxDcCount = 0;
    let maxEcCount = 0;
    const dcdata = new Array(rsBlocks.length);
    const ecdata = new Array(rsBlocks.length);
    for (let r = 0; r < rsBlocks.length; r += 1) {
      const dcCount = rsBlocks[r].dataCount;
      const ecCount = rsBlocks[r].totalCount - dcCount;
      maxDcCount = Math.max(maxDcCount, dcCount);
      maxEcCount = Math.max(maxEcCount, ecCount);
      dcdata[r] = new Array(dcCount);
      for (let i = 0; i < dcdata[r].length; i += 1) {
        dcdata[r][i] = 255 & buffer.getBuffer()[i + offset];
      }
      offset += dcCount;
      const rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
      const rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);
      const modPoly = rawPoly.mod(rsPoly);
      ecdata[r] = new Array(rsPoly.getLength() - 1);
      for (let i = 0; i < ecdata[r].length; i += 1) {
        const modIndex = i + modPoly.getLength() - ecdata[r].length;
        ecdata[r][i] = modIndex >= 0 ? modPoly.getAt(modIndex) : 0;
      }
    }
    let totalCodeCount = 0;
    for (let i = 0; i < rsBlocks.length; i += 1) {
      totalCodeCount += rsBlocks[i].totalCount;
    }
    const data = new Array(totalCodeCount);
    let index = 0;
    for (let i = 0; i < maxDcCount; i += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i < dcdata[r].length) {
          data[index] = dcdata[r][i];
          index += 1;
        }
      }
    }
    for (let i = 0; i < maxEcCount; i += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i < ecdata[r].length) {
          data[index] = ecdata[r][i];
          index += 1;
        }
      }
    }
    return data;
  };
  const createData = function(typeNumber2, errorCorrectionLevel2, dataList) {
    const rsBlocks = QRRSBlock.getRSBlocks(typeNumber2, errorCorrectionLevel2);
    const buffer = qrBitBuffer();
    for (let i = 0; i < dataList.length; i += 1) {
      const data = dataList[i];
      buffer.put(data.getMode(), 4);
      buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber2));
      data.write(buffer);
    }
    let totalDataCount = 0;
    for (let i = 0; i < rsBlocks.length; i += 1) {
      totalDataCount += rsBlocks[i].dataCount;
    }
    if (buffer.getLengthInBits() > totalDataCount * 8) {
      throw "code length overflow. (" + buffer.getLengthInBits() + ">" + totalDataCount * 8 + ")";
    }
    if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
      buffer.put(0, 4);
    }
    while (buffer.getLengthInBits() % 8 != 0) {
      buffer.putBit(false);
    }
    while (true) {
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD0, 8);
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD1, 8);
    }
    return createBytes(buffer, rsBlocks);
  };
  _this.addData = function(data, mode) {
    mode = mode || "Byte";
    let newData = null;
    switch (mode) {
      case "Numeric":
        newData = qrNumber(data);
        break;
      case "Alphanumeric":
        newData = qrAlphaNum(data);
        break;
      case "Byte":
        newData = qr8BitByte(data);
        break;
      case "Kanji":
        newData = qrKanji(data);
        break;
      default:
        throw "mode:" + mode;
    }
    _dataList.push(newData);
    _dataCache = null;
  };
  _this.isDark = function(row, col) {
    if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
      throw row + "," + col;
    }
    return _modules[row][col];
  };
  _this.getModuleCount = function() {
    return _moduleCount;
  };
  _this.make = function() {
    if (_typeNumber < 1) {
      let typeNumber2 = 1;
      for (; typeNumber2 < 40; typeNumber2++) {
        const rsBlocks = QRRSBlock.getRSBlocks(typeNumber2, _errorCorrectionLevel);
        const buffer = qrBitBuffer();
        for (let i = 0; i < _dataList.length; i++) {
          const data = _dataList[i];
          buffer.put(data.getMode(), 4);
          buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber2));
          data.write(buffer);
        }
        let totalDataCount = 0;
        for (let i = 0; i < rsBlocks.length; i++) {
          totalDataCount += rsBlocks[i].dataCount;
        }
        if (buffer.getLengthInBits() <= totalDataCount * 8) {
          break;
        }
      }
      _typeNumber = typeNumber2;
    }
    makeImpl(false, getBestMaskPattern());
  };
  _this.createTableTag = function(cellSize, margin) {
    cellSize = cellSize || 2;
    margin = typeof margin == "undefined" ? cellSize * 4 : margin;
    let qrHtml = "";
    qrHtml += '<table style="';
    qrHtml += " border-width: 0px; border-style: none;";
    qrHtml += " border-collapse: collapse;";
    qrHtml += " padding: 0px; margin: " + margin + "px;";
    qrHtml += '">';
    qrHtml += "<tbody>";
    for (let r = 0; r < _this.getModuleCount(); r += 1) {
      qrHtml += "<tr>";
      for (let c = 0; c < _this.getModuleCount(); c += 1) {
        qrHtml += '<td style="';
        qrHtml += " border-width: 0px; border-style: none;";
        qrHtml += " border-collapse: collapse;";
        qrHtml += " padding: 0px; margin: 0px;";
        qrHtml += " width: " + cellSize + "px;";
        qrHtml += " height: " + cellSize + "px;";
        qrHtml += " background-color: ";
        qrHtml += _this.isDark(r, c) ? "#000000" : "#ffffff";
        qrHtml += ";";
        qrHtml += '"/>';
      }
      qrHtml += "</tr>";
    }
    qrHtml += "</tbody>";
    qrHtml += "</table>";
    return qrHtml;
  };
  _this.createSvgTag = function(cellSize, margin, alt, title) {
    let opts = {};
    if (typeof arguments[0] == "object") {
      opts = arguments[0];
      cellSize = opts.cellSize;
      margin = opts.margin;
      alt = opts.alt;
      title = opts.title;
    }
    cellSize = cellSize || 2;
    margin = typeof margin == "undefined" ? cellSize * 4 : margin;
    alt = typeof alt === "string" ? { text: alt } : alt || {};
    alt.text = alt.text || null;
    alt.id = alt.text ? alt.id || "qrcode-description" : null;
    title = typeof title === "string" ? { text: title } : title || {};
    title.text = title.text || null;
    title.id = title.text ? title.id || "qrcode-title" : null;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    let c, mc, r, mr, qrSvg = "", rect;
    rect = "l" + cellSize + ",0 0," + cellSize + " -" + cellSize + ",0 0,-" + cellSize + "z ";
    qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
    qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : "";
    qrSvg += ' viewBox="0 0 ' + size + " " + size + '" ';
    qrSvg += ' preserveAspectRatio="xMinYMin meet"';
    qrSvg += title.text || alt.text ? ' role="img" aria-labelledby="' + escapeXml([title.id, alt.id].join(" ").trim()) + '"' : "";
    qrSvg += ">";
    qrSvg += title.text ? '<title id="' + escapeXml(title.id) + '">' + escapeXml(title.text) + "</title>" : "";
    qrSvg += alt.text ? '<description id="' + escapeXml(alt.id) + '">' + escapeXml(alt.text) + "</description>" : "";
    qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
    qrSvg += '<path d="';
    for (r = 0; r < _this.getModuleCount(); r += 1) {
      mr = r * cellSize + margin;
      for (c = 0; c < _this.getModuleCount(); c += 1) {
        if (_this.isDark(r, c)) {
          mc = c * cellSize + margin;
          qrSvg += "M" + mc + "," + mr + rect;
        }
      }
    }
    qrSvg += '" stroke="transparent" fill="black"/>';
    qrSvg += "</svg>";
    return qrSvg;
  };
  _this.createDataURL = function(cellSize, margin) {
    cellSize = cellSize || 2;
    margin = typeof margin == "undefined" ? cellSize * 4 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    const min = margin;
    const max = size - margin;
    return createDataURL(size, size, function(x, y) {
      if (min <= x && x < max && min <= y && y < max) {
        const c = Math.floor((x - min) / cellSize);
        const r = Math.floor((y - min) / cellSize);
        return _this.isDark(r, c) ? 0 : 1;
      } else {
        return 1;
      }
    });
  };
  _this.createImgTag = function(cellSize, margin, alt) {
    cellSize = cellSize || 2;
    margin = typeof margin == "undefined" ? cellSize * 4 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    let img = "";
    img += "<img";
    img += ' src="';
    img += _this.createDataURL(cellSize, margin);
    img += '"';
    img += ' width="';
    img += size;
    img += '"';
    img += ' height="';
    img += size;
    img += '"';
    if (alt) {
      img += ' alt="';
      img += escapeXml(alt);
      img += '"';
    }
    img += "/>";
    return img;
  };
  const escapeXml = function(s) {
    let escaped = "";
    for (let i = 0; i < s.length; i += 1) {
      const c = s.charAt(i);
      switch (c) {
        case "<":
          escaped += "&lt;";
          break;
        case ">":
          escaped += "&gt;";
          break;
        case "&":
          escaped += "&amp;";
          break;
        case '"':
          escaped += "&quot;";
          break;
        default:
          escaped += c;
          break;
      }
    }
    return escaped;
  };
  const _createHalfASCII = function(margin) {
    const cellSize = 1;
    margin = typeof margin == "undefined" ? cellSize * 2 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    const min = margin;
    const max = size - margin;
    let y, x, r1, r2, p;
    const blocks = {
      "\u2588\u2588": "\u2588",
      "\u2588 ": "\u2580",
      " \u2588": "\u2584",
      "  ": " "
    };
    const blocksLastLineNoMargin = {
      "\u2588\u2588": "\u2580",
      "\u2588 ": "\u2580",
      " \u2588": " ",
      "  ": " "
    };
    let ascii = "";
    for (y = 0; y < size; y += 2) {
      r1 = Math.floor((y - min) / cellSize);
      r2 = Math.floor((y + 1 - min) / cellSize);
      for (x = 0; x < size; x += 1) {
        p = "\u2588";
        if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
          p = " ";
        }
        if (min <= x && x < max && min <= y + 1 && y + 1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
          p += " ";
        } else {
          p += "\u2588";
        }
        ascii += margin < 1 && y + 1 >= max ? blocksLastLineNoMargin[p] : blocks[p];
      }
      ascii += "\n";
    }
    if (size % 2 && margin > 0) {
      return ascii.substring(0, ascii.length - size - 1) + Array(size + 1).join("\u2580");
    }
    return ascii.substring(0, ascii.length - 1);
  };
  _this.createASCII = function(cellSize, margin) {
    cellSize = cellSize || 1;
    if (cellSize < 2) {
      return _createHalfASCII(margin);
    }
    cellSize -= 1;
    margin = typeof margin == "undefined" ? cellSize * 2 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    const min = margin;
    const max = size - margin;
    let y, x, r, p;
    const white = Array(cellSize + 1).join("\u2588\u2588");
    const black = Array(cellSize + 1).join("  ");
    let ascii = "";
    let line = "";
    for (y = 0; y < size; y += 1) {
      r = Math.floor((y - min) / cellSize);
      line = "";
      for (x = 0; x < size; x += 1) {
        p = 1;
        if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
          p = 0;
        }
        line += p ? white : black;
      }
      for (r = 0; r < cellSize; r += 1) {
        ascii += line + "\n";
      }
    }
    return ascii.substring(0, ascii.length - 1);
  };
  _this.renderTo2dContext = function(context, cellSize) {
    cellSize = cellSize || 2;
    const length = _this.getModuleCount();
    for (let row = 0; row < length; row++) {
      for (let col = 0; col < length; col++) {
        context.fillStyle = _this.isDark(row, col) ? "black" : "white";
        context.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
      }
    }
  };
  return _this;
};
qrcode.stringToBytes = function(s) {
  const bytes = [];
  for (let i = 0; i < s.length; i += 1) {
    const c = s.charCodeAt(i);
    bytes.push(c & 255);
  }
  return bytes;
};
qrcode.createStringToBytes = function(unicodeData, numChars) {
  const unicodeMap = (function() {
    const bin = base64DecodeInputStream(unicodeData);
    const read = function() {
      const b = bin.read();
      if (b == -1) throw "eof";
      return b;
    };
    let count = 0;
    const unicodeMap2 = {};
    while (true) {
      const b0 = bin.read();
      if (b0 == -1) break;
      const b1 = read();
      const b2 = read();
      const b3 = read();
      const k = String.fromCharCode(b0 << 8 | b1);
      const v = b2 << 8 | b3;
      unicodeMap2[k] = v;
      count += 1;
    }
    if (count != numChars) {
      throw count + " != " + numChars;
    }
    return unicodeMap2;
  })();
  const unknownChar = "?".charCodeAt(0);
  return function(s) {
    const bytes = [];
    for (let i = 0; i < s.length; i += 1) {
      const c = s.charCodeAt(i);
      if (c < 128) {
        bytes.push(c);
      } else {
        const b = unicodeMap[s.charAt(i)];
        if (typeof b == "number") {
          if ((b & 255) == b) {
            bytes.push(b);
          } else {
            bytes.push(b >>> 8);
            bytes.push(b & 255);
          }
        } else {
          bytes.push(unknownChar);
        }
      }
    }
    return bytes;
  };
};
var QRMode = {
  MODE_NUMBER: 1 << 0,
  MODE_ALPHA_NUM: 1 << 1,
  MODE_8BIT_BYTE: 1 << 2,
  MODE_KANJI: 1 << 3
};
var QRErrorCorrectionLevel = {
  L: 1,
  M: 0,
  Q: 3,
  H: 2
};
var QRMaskPattern = {
  PATTERN000: 0,
  PATTERN001: 1,
  PATTERN010: 2,
  PATTERN011: 3,
  PATTERN100: 4,
  PATTERN101: 5,
  PATTERN110: 6,
  PATTERN111: 7
};
var QRUtil = (function() {
  const PATTERN_POSITION_TABLE = [
    [],
    [6, 18],
    [6, 22],
    [6, 26],
    [6, 30],
    [6, 34],
    [6, 22, 38],
    [6, 24, 42],
    [6, 26, 46],
    [6, 28, 50],
    [6, 30, 54],
    [6, 32, 58],
    [6, 34, 62],
    [6, 26, 46, 66],
    [6, 26, 48, 70],
    [6, 26, 50, 74],
    [6, 30, 54, 78],
    [6, 30, 56, 82],
    [6, 30, 58, 86],
    [6, 34, 62, 90],
    [6, 28, 50, 72, 94],
    [6, 26, 50, 74, 98],
    [6, 30, 54, 78, 102],
    [6, 28, 54, 80, 106],
    [6, 32, 58, 84, 110],
    [6, 30, 58, 86, 114],
    [6, 34, 62, 90, 118],
    [6, 26, 50, 74, 98, 122],
    [6, 30, 54, 78, 102, 126],
    [6, 26, 52, 78, 104, 130],
    [6, 30, 56, 82, 108, 134],
    [6, 34, 60, 86, 112, 138],
    [6, 30, 58, 86, 114, 142],
    [6, 34, 62, 90, 118, 146],
    [6, 30, 54, 78, 102, 126, 150],
    [6, 24, 50, 76, 102, 128, 154],
    [6, 28, 54, 80, 106, 132, 158],
    [6, 32, 58, 84, 110, 136, 162],
    [6, 26, 54, 82, 110, 138, 166],
    [6, 30, 58, 86, 114, 142, 170]
  ];
  const G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
  const G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
  const G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
  const _this = {};
  const getBCHDigit = function(data) {
    let digit = 0;
    while (data != 0) {
      digit += 1;
      data >>>= 1;
    }
    return digit;
  };
  _this.getBCHTypeInfo = function(data) {
    let d = data << 10;
    while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
      d ^= G15 << getBCHDigit(d) - getBCHDigit(G15);
    }
    return (data << 10 | d) ^ G15_MASK;
  };
  _this.getBCHTypeNumber = function(data) {
    let d = data << 12;
    while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
      d ^= G18 << getBCHDigit(d) - getBCHDigit(G18);
    }
    return data << 12 | d;
  };
  _this.getPatternPosition = function(typeNumber) {
    return PATTERN_POSITION_TABLE[typeNumber - 1];
  };
  _this.getMaskFunction = function(maskPattern) {
    switch (maskPattern) {
      case QRMaskPattern.PATTERN000:
        return function(i, j) {
          return (i + j) % 2 == 0;
        };
      case QRMaskPattern.PATTERN001:
        return function(i, j) {
          return i % 2 == 0;
        };
      case QRMaskPattern.PATTERN010:
        return function(i, j) {
          return j % 3 == 0;
        };
      case QRMaskPattern.PATTERN011:
        return function(i, j) {
          return (i + j) % 3 == 0;
        };
      case QRMaskPattern.PATTERN100:
        return function(i, j) {
          return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 == 0;
        };
      case QRMaskPattern.PATTERN101:
        return function(i, j) {
          return i * j % 2 + i * j % 3 == 0;
        };
      case QRMaskPattern.PATTERN110:
        return function(i, j) {
          return (i * j % 2 + i * j % 3) % 2 == 0;
        };
      case QRMaskPattern.PATTERN111:
        return function(i, j) {
          return (i * j % 3 + (i + j) % 2) % 2 == 0;
        };
      default:
        throw "bad maskPattern:" + maskPattern;
    }
  };
  _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
    let a = qrPolynomial([1], 0);
    for (let i = 0; i < errorCorrectLength; i += 1) {
      a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0));
    }
    return a;
  };
  _this.getLengthInBits = function(mode, type) {
    if (1 <= type && type < 10) {
      switch (mode) {
        case QRMode.MODE_NUMBER:
          return 10;
        case QRMode.MODE_ALPHA_NUM:
          return 9;
        case QRMode.MODE_8BIT_BYTE:
          return 8;
        case QRMode.MODE_KANJI:
          return 8;
        default:
          throw "mode:" + mode;
      }
    } else if (type < 27) {
      switch (mode) {
        case QRMode.MODE_NUMBER:
          return 12;
        case QRMode.MODE_ALPHA_NUM:
          return 11;
        case QRMode.MODE_8BIT_BYTE:
          return 16;
        case QRMode.MODE_KANJI:
          return 10;
        default:
          throw "mode:" + mode;
      }
    } else if (type < 41) {
      switch (mode) {
        case QRMode.MODE_NUMBER:
          return 14;
        case QRMode.MODE_ALPHA_NUM:
          return 13;
        case QRMode.MODE_8BIT_BYTE:
          return 16;
        case QRMode.MODE_KANJI:
          return 12;
        default:
          throw "mode:" + mode;
      }
    } else {
      throw "type:" + type;
    }
  };
  _this.getLostPoint = function(qrcode2) {
    const moduleCount = qrcode2.getModuleCount();
    let lostPoint = 0;
    for (let row = 0; row < moduleCount; row += 1) {
      for (let col = 0; col < moduleCount; col += 1) {
        let sameCount = 0;
        const dark = qrcode2.isDark(row, col);
        for (let r = -1; r <= 1; r += 1) {
          if (row + r < 0 || moduleCount <= row + r) {
            continue;
          }
          for (let c = -1; c <= 1; c += 1) {
            if (col + c < 0 || moduleCount <= col + c) {
              continue;
            }
            if (r == 0 && c == 0) {
              continue;
            }
            if (dark == qrcode2.isDark(row + r, col + c)) {
              sameCount += 1;
            }
          }
        }
        if (sameCount > 5) {
          lostPoint += 3 + sameCount - 5;
        }
      }
    }
    ;
    for (let row = 0; row < moduleCount - 1; row += 1) {
      for (let col = 0; col < moduleCount - 1; col += 1) {
        let count = 0;
        if (qrcode2.isDark(row, col)) count += 1;
        if (qrcode2.isDark(row + 1, col)) count += 1;
        if (qrcode2.isDark(row, col + 1)) count += 1;
        if (qrcode2.isDark(row + 1, col + 1)) count += 1;
        if (count == 0 || count == 4) {
          lostPoint += 3;
        }
      }
    }
    for (let row = 0; row < moduleCount; row += 1) {
      for (let col = 0; col < moduleCount - 6; col += 1) {
        if (qrcode2.isDark(row, col) && !qrcode2.isDark(row, col + 1) && qrcode2.isDark(row, col + 2) && qrcode2.isDark(row, col + 3) && qrcode2.isDark(row, col + 4) && !qrcode2.isDark(row, col + 5) && qrcode2.isDark(row, col + 6)) {
          lostPoint += 40;
        }
      }
    }
    for (let col = 0; col < moduleCount; col += 1) {
      for (let row = 0; row < moduleCount - 6; row += 1) {
        if (qrcode2.isDark(row, col) && !qrcode2.isDark(row + 1, col) && qrcode2.isDark(row + 2, col) && qrcode2.isDark(row + 3, col) && qrcode2.isDark(row + 4, col) && !qrcode2.isDark(row + 5, col) && qrcode2.isDark(row + 6, col)) {
          lostPoint += 40;
        }
      }
    }
    let darkCount = 0;
    for (let col = 0; col < moduleCount; col += 1) {
      for (let row = 0; row < moduleCount; row += 1) {
        if (qrcode2.isDark(row, col)) {
          darkCount += 1;
        }
      }
    }
    const ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
    lostPoint += ratio * 10;
    return lostPoint;
  };
  return _this;
})();
var QRMath = (function() {
  const EXP_TABLE = new Array(256);
  const LOG_TABLE = new Array(256);
  for (let i = 0; i < 8; i += 1) {
    EXP_TABLE[i] = 1 << i;
  }
  for (let i = 8; i < 256; i += 1) {
    EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
  }
  for (let i = 0; i < 255; i += 1) {
    LOG_TABLE[EXP_TABLE[i]] = i;
  }
  const _this = {};
  _this.glog = function(n) {
    if (n < 1) {
      throw "glog(" + n + ")";
    }
    return LOG_TABLE[n];
  };
  _this.gexp = function(n) {
    while (n < 0) {
      n += 255;
    }
    while (n >= 256) {
      n -= 255;
    }
    return EXP_TABLE[n];
  };
  return _this;
})();
var qrPolynomial = function(num, shift) {
  if (typeof num.length == "undefined") {
    throw num.length + "/" + shift;
  }
  const _num = (function() {
    let offset = 0;
    while (offset < num.length && num[offset] == 0) {
      offset += 1;
    }
    const _num2 = new Array(num.length - offset + shift);
    for (let i = 0; i < num.length - offset; i += 1) {
      _num2[i] = num[i + offset];
    }
    return _num2;
  })();
  const _this = {};
  _this.getAt = function(index) {
    return _num[index];
  };
  _this.getLength = function() {
    return _num.length;
  };
  _this.multiply = function(e) {
    const num2 = new Array(_this.getLength() + e.getLength() - 1);
    for (let i = 0; i < _this.getLength(); i += 1) {
      for (let j = 0; j < e.getLength(); j += 1) {
        num2[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i)) + QRMath.glog(e.getAt(j)));
      }
    }
    return qrPolynomial(num2, 0);
  };
  _this.mod = function(e) {
    if (_this.getLength() - e.getLength() < 0) {
      return _this;
    }
    const ratio = QRMath.glog(_this.getAt(0)) - QRMath.glog(e.getAt(0));
    const num2 = new Array(_this.getLength());
    for (let i = 0; i < _this.getLength(); i += 1) {
      num2[i] = _this.getAt(i);
    }
    for (let i = 0; i < e.getLength(); i += 1) {
      num2[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i)) + ratio);
    }
    return qrPolynomial(num2, 0).mod(e);
  };
  return _this;
};
var QRRSBlock = (function() {
  const RS_BLOCK_TABLE = [
    // L
    // M
    // Q
    // H
    // 1
    [1, 26, 19],
    [1, 26, 16],
    [1, 26, 13],
    [1, 26, 9],
    // 2
    [1, 44, 34],
    [1, 44, 28],
    [1, 44, 22],
    [1, 44, 16],
    // 3
    [1, 70, 55],
    [1, 70, 44],
    [2, 35, 17],
    [2, 35, 13],
    // 4
    [1, 100, 80],
    [2, 50, 32],
    [2, 50, 24],
    [4, 25, 9],
    // 5
    [1, 134, 108],
    [2, 67, 43],
    [2, 33, 15, 2, 34, 16],
    [2, 33, 11, 2, 34, 12],
    // 6
    [2, 86, 68],
    [4, 43, 27],
    [4, 43, 19],
    [4, 43, 15],
    // 7
    [2, 98, 78],
    [4, 49, 31],
    [2, 32, 14, 4, 33, 15],
    [4, 39, 13, 1, 40, 14],
    // 8
    [2, 121, 97],
    [2, 60, 38, 2, 61, 39],
    [4, 40, 18, 2, 41, 19],
    [4, 40, 14, 2, 41, 15],
    // 9
    [2, 146, 116],
    [3, 58, 36, 2, 59, 37],
    [4, 36, 16, 4, 37, 17],
    [4, 36, 12, 4, 37, 13],
    // 10
    [2, 86, 68, 2, 87, 69],
    [4, 69, 43, 1, 70, 44],
    [6, 43, 19, 2, 44, 20],
    [6, 43, 15, 2, 44, 16],
    // 11
    [4, 101, 81],
    [1, 80, 50, 4, 81, 51],
    [4, 50, 22, 4, 51, 23],
    [3, 36, 12, 8, 37, 13],
    // 12
    [2, 116, 92, 2, 117, 93],
    [6, 58, 36, 2, 59, 37],
    [4, 46, 20, 6, 47, 21],
    [7, 42, 14, 4, 43, 15],
    // 13
    [4, 133, 107],
    [8, 59, 37, 1, 60, 38],
    [8, 44, 20, 4, 45, 21],
    [12, 33, 11, 4, 34, 12],
    // 14
    [3, 145, 115, 1, 146, 116],
    [4, 64, 40, 5, 65, 41],
    [11, 36, 16, 5, 37, 17],
    [11, 36, 12, 5, 37, 13],
    // 15
    [5, 109, 87, 1, 110, 88],
    [5, 65, 41, 5, 66, 42],
    [5, 54, 24, 7, 55, 25],
    [11, 36, 12, 7, 37, 13],
    // 16
    [5, 122, 98, 1, 123, 99],
    [7, 73, 45, 3, 74, 46],
    [15, 43, 19, 2, 44, 20],
    [3, 45, 15, 13, 46, 16],
    // 17
    [1, 135, 107, 5, 136, 108],
    [10, 74, 46, 1, 75, 47],
    [1, 50, 22, 15, 51, 23],
    [2, 42, 14, 17, 43, 15],
    // 18
    [5, 150, 120, 1, 151, 121],
    [9, 69, 43, 4, 70, 44],
    [17, 50, 22, 1, 51, 23],
    [2, 42, 14, 19, 43, 15],
    // 19
    [3, 141, 113, 4, 142, 114],
    [3, 70, 44, 11, 71, 45],
    [17, 47, 21, 4, 48, 22],
    [9, 39, 13, 16, 40, 14],
    // 20
    [3, 135, 107, 5, 136, 108],
    [3, 67, 41, 13, 68, 42],
    [15, 54, 24, 5, 55, 25],
    [15, 43, 15, 10, 44, 16],
    // 21
    [4, 144, 116, 4, 145, 117],
    [17, 68, 42],
    [17, 50, 22, 6, 51, 23],
    [19, 46, 16, 6, 47, 17],
    // 22
    [2, 139, 111, 7, 140, 112],
    [17, 74, 46],
    [7, 54, 24, 16, 55, 25],
    [34, 37, 13],
    // 23
    [4, 151, 121, 5, 152, 122],
    [4, 75, 47, 14, 76, 48],
    [11, 54, 24, 14, 55, 25],
    [16, 45, 15, 14, 46, 16],
    // 24
    [6, 147, 117, 4, 148, 118],
    [6, 73, 45, 14, 74, 46],
    [11, 54, 24, 16, 55, 25],
    [30, 46, 16, 2, 47, 17],
    // 25
    [8, 132, 106, 4, 133, 107],
    [8, 75, 47, 13, 76, 48],
    [7, 54, 24, 22, 55, 25],
    [22, 45, 15, 13, 46, 16],
    // 26
    [10, 142, 114, 2, 143, 115],
    [19, 74, 46, 4, 75, 47],
    [28, 50, 22, 6, 51, 23],
    [33, 46, 16, 4, 47, 17],
    // 27
    [8, 152, 122, 4, 153, 123],
    [22, 73, 45, 3, 74, 46],
    [8, 53, 23, 26, 54, 24],
    [12, 45, 15, 28, 46, 16],
    // 28
    [3, 147, 117, 10, 148, 118],
    [3, 73, 45, 23, 74, 46],
    [4, 54, 24, 31, 55, 25],
    [11, 45, 15, 31, 46, 16],
    // 29
    [7, 146, 116, 7, 147, 117],
    [21, 73, 45, 7, 74, 46],
    [1, 53, 23, 37, 54, 24],
    [19, 45, 15, 26, 46, 16],
    // 30
    [5, 145, 115, 10, 146, 116],
    [19, 75, 47, 10, 76, 48],
    [15, 54, 24, 25, 55, 25],
    [23, 45, 15, 25, 46, 16],
    // 31
    [13, 145, 115, 3, 146, 116],
    [2, 74, 46, 29, 75, 47],
    [42, 54, 24, 1, 55, 25],
    [23, 45, 15, 28, 46, 16],
    // 32
    [17, 145, 115],
    [10, 74, 46, 23, 75, 47],
    [10, 54, 24, 35, 55, 25],
    [19, 45, 15, 35, 46, 16],
    // 33
    [17, 145, 115, 1, 146, 116],
    [14, 74, 46, 21, 75, 47],
    [29, 54, 24, 19, 55, 25],
    [11, 45, 15, 46, 46, 16],
    // 34
    [13, 145, 115, 6, 146, 116],
    [14, 74, 46, 23, 75, 47],
    [44, 54, 24, 7, 55, 25],
    [59, 46, 16, 1, 47, 17],
    // 35
    [12, 151, 121, 7, 152, 122],
    [12, 75, 47, 26, 76, 48],
    [39, 54, 24, 14, 55, 25],
    [22, 45, 15, 41, 46, 16],
    // 36
    [6, 151, 121, 14, 152, 122],
    [6, 75, 47, 34, 76, 48],
    [46, 54, 24, 10, 55, 25],
    [2, 45, 15, 64, 46, 16],
    // 37
    [17, 152, 122, 4, 153, 123],
    [29, 74, 46, 14, 75, 47],
    [49, 54, 24, 10, 55, 25],
    [24, 45, 15, 46, 46, 16],
    // 38
    [4, 152, 122, 18, 153, 123],
    [13, 74, 46, 32, 75, 47],
    [48, 54, 24, 14, 55, 25],
    [42, 45, 15, 32, 46, 16],
    // 39
    [20, 147, 117, 4, 148, 118],
    [40, 75, 47, 7, 76, 48],
    [43, 54, 24, 22, 55, 25],
    [10, 45, 15, 67, 46, 16],
    // 40
    [19, 148, 118, 6, 149, 119],
    [18, 75, 47, 31, 76, 48],
    [34, 54, 24, 34, 55, 25],
    [20, 45, 15, 61, 46, 16]
  ];
  const qrRSBlock = function(totalCount, dataCount) {
    const _this2 = {};
    _this2.totalCount = totalCount;
    _this2.dataCount = dataCount;
    return _this2;
  };
  const _this = {};
  const getRsBlockTable = function(typeNumber, errorCorrectionLevel) {
    switch (errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default:
        return void 0;
    }
  };
  _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {
    const rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
    if (typeof rsBlock == "undefined") {
      throw "bad rs block @ typeNumber:" + typeNumber + "/errorCorrectionLevel:" + errorCorrectionLevel;
    }
    const length = rsBlock.length / 3;
    const list = [];
    for (let i = 0; i < length; i += 1) {
      const count = rsBlock[i * 3 + 0];
      const totalCount = rsBlock[i * 3 + 1];
      const dataCount = rsBlock[i * 3 + 2];
      for (let j = 0; j < count; j += 1) {
        list.push(qrRSBlock(totalCount, dataCount));
      }
    }
    return list;
  };
  return _this;
})();
var qrBitBuffer = function() {
  const _buffer = [];
  let _length = 0;
  const _this = {};
  _this.getBuffer = function() {
    return _buffer;
  };
  _this.getAt = function(index) {
    const bufIndex = Math.floor(index / 8);
    return (_buffer[bufIndex] >>> 7 - index % 8 & 1) == 1;
  };
  _this.put = function(num, length) {
    for (let i = 0; i < length; i += 1) {
      _this.putBit((num >>> length - i - 1 & 1) == 1);
    }
  };
  _this.getLengthInBits = function() {
    return _length;
  };
  _this.putBit = function(bit) {
    const bufIndex = Math.floor(_length / 8);
    if (_buffer.length <= bufIndex) {
      _buffer.push(0);
    }
    if (bit) {
      _buffer[bufIndex] |= 128 >>> _length % 8;
    }
    _length += 1;
  };
  return _this;
};
var qrNumber = function(data) {
  const _mode = QRMode.MODE_NUMBER;
  const _data = data;
  const _this = {};
  _this.getMode = function() {
    return _mode;
  };
  _this.getLength = function(buffer) {
    return _data.length;
  };
  _this.write = function(buffer) {
    const data2 = _data;
    let i = 0;
    while (i + 2 < data2.length) {
      buffer.put(strToNum(data2.substring(i, i + 3)), 10);
      i += 3;
    }
    if (i < data2.length) {
      if (data2.length - i == 1) {
        buffer.put(strToNum(data2.substring(i, i + 1)), 4);
      } else if (data2.length - i == 2) {
        buffer.put(strToNum(data2.substring(i, i + 2)), 7);
      }
    }
  };
  const strToNum = function(s) {
    let num = 0;
    for (let i = 0; i < s.length; i += 1) {
      num = num * 10 + chatToNum(s.charAt(i));
    }
    return num;
  };
  const chatToNum = function(c) {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    }
    throw "illegal char :" + c;
  };
  return _this;
};
var qrAlphaNum = function(data) {
  const _mode = QRMode.MODE_ALPHA_NUM;
  const _data = data;
  const _this = {};
  _this.getMode = function() {
    return _mode;
  };
  _this.getLength = function(buffer) {
    return _data.length;
  };
  _this.write = function(buffer) {
    const s = _data;
    let i = 0;
    while (i + 1 < s.length) {
      buffer.put(
        getCode(s.charAt(i)) * 45 + getCode(s.charAt(i + 1)),
        11
      );
      i += 2;
    }
    if (i < s.length) {
      buffer.put(getCode(s.charAt(i)), 6);
    }
  };
  const getCode = function(c) {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    } else if ("A" <= c && c <= "Z") {
      return c.charCodeAt(0) - "A".charCodeAt(0) + 10;
    } else {
      switch (c) {
        case " ":
          return 36;
        case "$":
          return 37;
        case "%":
          return 38;
        case "*":
          return 39;
        case "+":
          return 40;
        case "-":
          return 41;
        case ".":
          return 42;
        case "/":
          return 43;
        case ":":
          return 44;
        default:
          throw "illegal char :" + c;
      }
    }
  };
  return _this;
};
var qr8BitByte = function(data) {
  const _mode = QRMode.MODE_8BIT_BYTE;
  const _data = data;
  const _bytes = qrcode.stringToBytes(data);
  const _this = {};
  _this.getMode = function() {
    return _mode;
  };
  _this.getLength = function(buffer) {
    return _bytes.length;
  };
  _this.write = function(buffer) {
    for (let i = 0; i < _bytes.length; i += 1) {
      buffer.put(_bytes[i], 8);
    }
  };
  return _this;
};
var qrKanji = function(data) {
  const _mode = QRMode.MODE_KANJI;
  const _data = data;
  const stringToBytes2 = qrcode.stringToBytes;
  !(function(c, code) {
    const test = stringToBytes2(c);
    if (test.length != 2 || (test[0] << 8 | test[1]) != code) {
      throw "sjis not supported.";
    }
  })("\u53CB", 38726);
  const _bytes = stringToBytes2(data);
  const _this = {};
  _this.getMode = function() {
    return _mode;
  };
  _this.getLength = function(buffer) {
    return ~~(_bytes.length / 2);
  };
  _this.write = function(buffer) {
    const data2 = _bytes;
    let i = 0;
    while (i + 1 < data2.length) {
      let c = (255 & data2[i]) << 8 | 255 & data2[i + 1];
      if (33088 <= c && c <= 40956) {
        c -= 33088;
      } else if (57408 <= c && c <= 60351) {
        c -= 49472;
      } else {
        throw "illegal char at " + (i + 1) + "/" + c;
      }
      c = (c >>> 8 & 255) * 192 + (c & 255);
      buffer.put(c, 13);
      i += 2;
    }
    if (i < data2.length) {
      throw "illegal char at " + (i + 1);
    }
  };
  return _this;
};
var byteArrayOutputStream = function() {
  const _bytes = [];
  const _this = {};
  _this.writeByte = function(b) {
    _bytes.push(b & 255);
  };
  _this.writeShort = function(i) {
    _this.writeByte(i);
    _this.writeByte(i >>> 8);
  };
  _this.writeBytes = function(b, off, len) {
    off = off || 0;
    len = len || b.length;
    for (let i = 0; i < len; i += 1) {
      _this.writeByte(b[i + off]);
    }
  };
  _this.writeString = function(s) {
    for (let i = 0; i < s.length; i += 1) {
      _this.writeByte(s.charCodeAt(i));
    }
  };
  _this.toByteArray = function() {
    return _bytes;
  };
  _this.toString = function() {
    let s = "";
    s += "[";
    for (let i = 0; i < _bytes.length; i += 1) {
      if (i > 0) {
        s += ",";
      }
      s += _bytes[i];
    }
    s += "]";
    return s;
  };
  return _this;
};
var base64EncodeOutputStream = function() {
  let _buffer = 0;
  let _buflen = 0;
  let _length = 0;
  let _base64 = "";
  const _this = {};
  const writeEncoded = function(b) {
    _base64 += String.fromCharCode(encode(b & 63));
  };
  const encode = function(n) {
    if (n < 0) {
      throw "n:" + n;
    } else if (n < 26) {
      return 65 + n;
    } else if (n < 52) {
      return 97 + (n - 26);
    } else if (n < 62) {
      return 48 + (n - 52);
    } else if (n == 62) {
      return 43;
    } else if (n == 63) {
      return 47;
    } else {
      throw "n:" + n;
    }
  };
  _this.writeByte = function(n) {
    _buffer = _buffer << 8 | n & 255;
    _buflen += 8;
    _length += 1;
    while (_buflen >= 6) {
      writeEncoded(_buffer >>> _buflen - 6);
      _buflen -= 6;
    }
  };
  _this.flush = function() {
    if (_buflen > 0) {
      writeEncoded(_buffer << 6 - _buflen);
      _buffer = 0;
      _buflen = 0;
    }
    if (_length % 3 != 0) {
      const padlen = 3 - _length % 3;
      for (let i = 0; i < padlen; i += 1) {
        _base64 += "=";
      }
    }
  };
  _this.toString = function() {
    return _base64;
  };
  return _this;
};
var base64DecodeInputStream = function(str) {
  const _str = str;
  let _pos = 0;
  let _buffer = 0;
  let _buflen = 0;
  const _this = {};
  _this.read = function() {
    while (_buflen < 8) {
      if (_pos >= _str.length) {
        if (_buflen == 0) {
          return -1;
        }
        throw "unexpected end of file./" + _buflen;
      }
      const c = _str.charAt(_pos);
      _pos += 1;
      if (c == "=") {
        _buflen = 0;
        return -1;
      } else if (c.match(/^\s$/)) {
        continue;
      }
      _buffer = _buffer << 6 | decode(c.charCodeAt(0));
      _buflen += 6;
    }
    const n = _buffer >>> _buflen - 8 & 255;
    _buflen -= 8;
    return n;
  };
  const decode = function(c) {
    if (65 <= c && c <= 90) {
      return c - 65;
    } else if (97 <= c && c <= 122) {
      return c - 97 + 26;
    } else if (48 <= c && c <= 57) {
      return c - 48 + 52;
    } else if (c == 43) {
      return 62;
    } else if (c == 47) {
      return 63;
    } else {
      throw "c:" + c;
    }
  };
  return _this;
};
var gifImage = function(width, height) {
  const _width = width;
  const _height = height;
  const _data = new Array(width * height);
  const _this = {};
  _this.setPixel = function(x, y, pixel) {
    _data[y * _width + x] = pixel;
  };
  _this.write = function(out) {
    out.writeString("GIF87a");
    out.writeShort(_width);
    out.writeShort(_height);
    out.writeByte(128);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(255);
    out.writeByte(255);
    out.writeByte(255);
    out.writeString(",");
    out.writeShort(0);
    out.writeShort(0);
    out.writeShort(_width);
    out.writeShort(_height);
    out.writeByte(0);
    const lzwMinCodeSize = 2;
    const raster = getLZWRaster(lzwMinCodeSize);
    out.writeByte(lzwMinCodeSize);
    let offset = 0;
    while (raster.length - offset > 255) {
      out.writeByte(255);
      out.writeBytes(raster, offset, 255);
      offset += 255;
    }
    out.writeByte(raster.length - offset);
    out.writeBytes(raster, offset, raster.length - offset);
    out.writeByte(0);
    out.writeString(";");
  };
  const bitOutputStream = function(out) {
    const _out = out;
    let _bitLength = 0;
    let _bitBuffer = 0;
    const _this2 = {};
    _this2.write = function(data, length) {
      if (data >>> length != 0) {
        throw "length over";
      }
      while (_bitLength + length >= 8) {
        _out.writeByte(255 & (data << _bitLength | _bitBuffer));
        length -= 8 - _bitLength;
        data >>>= 8 - _bitLength;
        _bitBuffer = 0;
        _bitLength = 0;
      }
      _bitBuffer = data << _bitLength | _bitBuffer;
      _bitLength = _bitLength + length;
    };
    _this2.flush = function() {
      if (_bitLength > 0) {
        _out.writeByte(_bitBuffer);
      }
    };
    return _this2;
  };
  const getLZWRaster = function(lzwMinCodeSize) {
    const clearCode = 1 << lzwMinCodeSize;
    const endCode = (1 << lzwMinCodeSize) + 1;
    let bitLength = lzwMinCodeSize + 1;
    const table = lzwTable();
    for (let i = 0; i < clearCode; i += 1) {
      table.add(String.fromCharCode(i));
    }
    table.add(String.fromCharCode(clearCode));
    table.add(String.fromCharCode(endCode));
    const byteOut = byteArrayOutputStream();
    const bitOut = bitOutputStream(byteOut);
    bitOut.write(clearCode, bitLength);
    let dataIndex = 0;
    let s = String.fromCharCode(_data[dataIndex]);
    dataIndex += 1;
    while (dataIndex < _data.length) {
      const c = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;
      if (table.contains(s + c)) {
        s = s + c;
      } else {
        bitOut.write(table.indexOf(s), bitLength);
        if (table.size() < 4095) {
          if (table.size() == 1 << bitLength) {
            bitLength += 1;
          }
          table.add(s + c);
        }
        s = c;
      }
    }
    bitOut.write(table.indexOf(s), bitLength);
    bitOut.write(endCode, bitLength);
    bitOut.flush();
    return byteOut.toByteArray();
  };
  const lzwTable = function() {
    const _map = {};
    let _size = 0;
    const _this2 = {};
    _this2.add = function(key) {
      if (_this2.contains(key)) {
        throw "dup key:" + key;
      }
      _map[key] = _size;
      _size += 1;
    };
    _this2.size = function() {
      return _size;
    };
    _this2.indexOf = function(key) {
      return _map[key];
    };
    _this2.contains = function(key) {
      return typeof _map[key] != "undefined";
    };
    return _this2;
  };
  return _this;
};
var createDataURL = function(width, height, getPixel) {
  const gif = gifImage(width, height);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      gif.setPixel(x, y, getPixel(x, y));
    }
  }
  const b = byteArrayOutputStream();
  gif.write(b);
  const base64 = base64EncodeOutputStream();
  const bytes = b.toByteArray();
  for (let i = 0; i < bytes.length; i += 1) {
    base64.writeByte(bytes[i]);
  }
  base64.flush();
  return "data:image/gif;base64," + base64;
};
var qrcode_default = qrcode;
var stringToBytes = qrcode.stringToBytes;

// src/modules/blue-noise-dither.ts
var ECC_MAP = {
  L: "L",
  M: "M",
  Q: "Q",
  H: "H",
  low: "L",
  medium: "M",
  quartile: "Q",
  high: "H"
};
var ALIGNMENT_POSITIONS = [
  null,
  [],
  [6, 18],
  [6, 22],
  [6, 26],
  [6, 30],
  [6, 34],
  [6, 22, 38],
  [6, 24, 42],
  [6, 26, 46],
  [6, 28, 50],
  [6, 30, 54],
  [6, 32, 58],
  [6, 34, 62],
  [6, 26, 46, 66],
  [6, 26, 48, 70],
  [6, 26, 50, 74],
  [6, 30, 54, 78],
  [6, 30, 56, 82],
  [6, 30, 58, 86],
  [6, 34, 62, 90],
  [6, 28, 50, 72, 94],
  [6, 26, 50, 74, 98],
  [6, 30, 54, 78, 102],
  [6, 28, 54, 80, 106],
  [6, 32, 58, 84, 110],
  [6, 30, 58, 86, 114],
  [6, 34, 62, 90, 118],
  [6, 26, 50, 74, 98, 122],
  [6, 30, 54, 78, 102, 126],
  [6, 26, 52, 78, 104, 130],
  [6, 30, 56, 82, 108, 134],
  [6, 34, 60, 86, 112, 138],
  [6, 30, 58, 86, 114, 142],
  [6, 34, 62, 90, 118, 146],
  [6, 30, 54, 78, 102, 126, 150],
  [6, 24, 50, 76, 102, 128, 154],
  [6, 28, 54, 80, 106, 132, 158],
  [6, 32, 58, 84, 110, 136, 162],
  [6, 26, 54, 82, 110, 138, 166],
  [6, 30, 58, 86, 114, 142, 170]
];
var BLUE_NOISE_TILE_SIZE = 64;
var BLUE_NOISE_64 = generateBlueNoiseTile();
function generateBlueNoiseTile() {
  const size = BLUE_NOISE_TILE_SIZE;
  const tile = new Array(size * size);
  const phi = 1.618033988749895;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const ign = 52.9829189 * ((0.06711056 * x + 583715e-8 * y) % 1) % 1;
      const offset = (x * phi + y * phi * phi) % 1;
      tile[y * size + x] = (ign + offset * 0.5) % 1;
    }
  }
  return tile;
}
function sampleBlueNoise(x, y) {
  const size = BLUE_NOISE_TILE_SIZE;
  const tx = (x % size + size) % size;
  const ty = (y % size + size) % size;
  return BLUE_NOISE_64[ty * size + tx];
}
function isLocked(moduleCount, x, y, scale) {
  const l = moduleCount / scale;
  const sx = Math.floor(x / scale);
  const sy = Math.floor(y / scale);
  if (sx < 0 || sy < 0 || sx >= l || sy >= l) return true;
  if (sx < 7 && sy < 7) return true;
  if (sx < 7 && sy > l - 8) return true;
  if (sx > l - 8 && sy < 7) return true;
  if (sx === 6 || sy === 6) return true;
  const version = (l - 17) / 4;
  const positions = ALIGNMENT_POSITIONS[version];
  if (positions && positions.length > 0) {
    for (const px of positions) {
      for (const py of positions) {
        if (px < 8 && py < 8) continue;
        if (px < 8 && py > l - 9) continue;
        if (px > l - 9 && py < 8) continue;
        if (Math.abs(sx - px) <= 2 && Math.abs(sy - py) <= 2) {
          return true;
        }
      }
    }
  }
  return false;
}
function isData(x, y, scale) {
  const m = Math.floor(scale / 2);
  const xs = x % scale;
  const ys = y % scale;
  if (xs === m && ys === m) return true;
  if (scale % 2 === 1) return false;
  if (xs === m && ys === m - 1) return true;
  if (xs === m - 1 && ys === m) return true;
  if (xs === m - 1 && ys === m - 1) return true;
  return false;
}
function loadImageDataRGB(canvas, size) {
  const tempCanvas = document.createElement("canvas");
  tempCanvas.width = size;
  tempCanvas.height = size;
  const ctx = tempCanvas.getContext("2d");
  ctx.drawImage(canvas, 0, 0, size, size);
  const imgData = ctx.getImageData(0, 0, size, size);
  const output = [];
  for (let y = 0; y < size; y++) {
    const row = [];
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      row.push({
        r: imgData.data[i] / 255,
        g: imgData.data[i + 1] / 255,
        b: imgData.data[i + 2] / 255
      });
    }
    output.push(row);
  }
  return output;
}
function rgbToGray(r, g, b) {
  return r * 0.299 + g * 0.587 + b * 0.114;
}
function convertToGrayscale(imageData) {
  for (let y = 0; y < imageData.length; y++) {
    for (let x = 0; x < imageData[y].length; x++) {
      const { r, g, b } = imageData[y][x];
      const gray = rgbToGray(r, g, b);
      imageData[y][x] = { r: gray, g: gray, b: gray };
    }
  }
}
function blueNoiseDitherFreePoints(imageData, moduleCount, scale, colorMode) {
  const size = imageData.length;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (isLocked(moduleCount, x, y, scale)) continue;
      if (isData(x, y, scale)) continue;
      const pixel = imageData[y][x];
      const threshold = sampleBlueNoise(x, y);
      if (colorMode === "bw") {
        const gray = rgbToGray(pixel.r, pixel.g, pixel.b);
        const newVal = gray > threshold ? 1 : 0;
        imageData[y][x] = { r: newVal, g: newVal, b: newVal };
      } else if (colorMode === "grayscale") {
        const gray = rgbToGray(pixel.r, pixel.g, pixel.b);
        const levels = 4;
        const scaled = gray * (levels - 1);
        const low = Math.floor(scaled);
        const high = Math.min(low + 1, levels - 1);
        const frac = scaled - low;
        const newVal = (frac > threshold ? high : low) / (levels - 1);
        imageData[y][x] = { r: newVal, g: newVal, b: newVal };
      } else {
        let quantizeChannel = function(val, noiseOffset) {
          const t = (threshold + noiseOffset) % 1;
          const scaled = val * (levels - 1);
          const low = Math.floor(scaled);
          const high = Math.min(low + 1, levels - 1);
          const frac = scaled - low;
          return (frac > t ? high : low) / (levels - 1);
        };
        const levels = 4;
        imageData[y][x] = {
          r: quantizeChannel(pixel.r, 0),
          g: quantizeChannel(pixel.g, 0.33),
          b: quantizeChannel(pixel.b, 0.67)
        };
      }
    }
  }
}
function generateBlueNoiseDithered(options) {
  const {
    text,
    ecc,
    version = 0,
    scale,
    overlayCanvas,
    overlayIntensity = 50,
    colorMode = "color"
  } = options;
  const eccLevel = ECC_MAP[ecc] || "Q";
  const typeNumber = version || 0;
  const qr = qrcode_default(typeNumber, eccLevel);
  qr.addData(text);
  qr.make();
  const moduleCount = qr.getModuleCount();
  const scaledSize = moduleCount * scale;
  const matrix = [];
  const colors = [];
  for (let y = 0; y < scaledSize; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < scaledSize; x++) {
      const qrX = Math.floor(x / scale);
      const qrY = Math.floor(y / scale);
      const isDark = qr.isDark(qrY, qrX);
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    matrix.push(matrixRow);
    colors.push(colorRow);
  }
  if (!overlayCanvas) {
    return { matrix, colors };
  }
  const imageData = loadImageDataRGB(overlayCanvas, scaledSize);
  const intensity = overlayIntensity / 100;
  if (colorMode === "grayscale" || colorMode === "bw") {
    convertToGrayscale(imageData);
  }
  blueNoiseDitherFreePoints(imageData, scaledSize, scale, colorMode);
  for (let y = 0; y < scaledSize; y++) {
    for (let x = 0; x < scaledSize; x++) {
      if (isLocked(scaledSize, x, y, scale)) continue;
      if (isData(x, y, scale)) continue;
      const pixel = imageData[y][x];
      const brightness = rgbToGray(pixel.r, pixel.g, pixel.b);
      const useImage = sampleBlueNoise(x + 17, y + 31) < intensity;
      if (useImage) {
        matrix[y][x] = brightness < 0.5;
        colors[y][x] = {
          r: Math.round(Math.max(0, Math.min(1, pixel.r)) * 255),
          g: Math.round(Math.max(0, Math.min(1, pixel.g)) * 255),
          b: Math.round(Math.max(0, Math.min(1, pixel.b)) * 255)
        };
      }
    }
  }
  return { matrix, colors };
}

// src/modules/qr-core.ts
var ALIGNMENT_POSITIONS2 = [
  null,
  [],
  [6, 18],
  [6, 22],
  [6, 26],
  [6, 30],
  [6, 34],
  [6, 22, 38],
  [6, 24, 42],
  [6, 26, 46],
  [6, 28, 50],
  [6, 30, 54],
  [6, 32, 58],
  [6, 34, 62],
  [6, 26, 46, 66],
  [6, 26, 48, 70],
  [6, 26, 50, 74],
  [6, 30, 54, 78],
  [6, 30, 56, 82],
  [6, 30, 58, 86],
  [6, 34, 62, 90],
  [6, 28, 50, 72, 94],
  [6, 26, 50, 74, 98],
  [6, 30, 54, 78, 102],
  [6, 28, 54, 80, 106],
  [6, 32, 58, 84, 110],
  [6, 30, 58, 86, 114],
  [6, 34, 62, 90, 118],
  [6, 26, 50, 74, 98, 122],
  [6, 30, 54, 78, 102, 126],
  [6, 26, 52, 78, 104, 130],
  [6, 30, 56, 82, 108, 134],
  [6, 34, 60, 86, 112, 138],
  [6, 30, 58, 86, 114, 142],
  [6, 34, 62, 90, 118, 146],
  [6, 30, 54, 78, 102, 126, 150],
  [6, 24, 50, 76, 102, 128, 154],
  [6, 28, 54, 80, 106, 132, 158],
  [6, 32, 58, 84, 110, 136, 162],
  [6, 26, 54, 82, 110, 138, 166],
  [6, 30, 58, 86, 114, 142, 170]
];
var ECC_CAPACITIES = {
  L: [17, 32, 53, 78, 106, 134, 154, 192, 230, 271, 321, 367, 425, 458, 520, 586, 644, 718, 792, 858, 929, 1003, 1091, 1171, 1273, 1367, 1465, 1528, 1628, 1732, 1840, 1952, 2068, 2188, 2303, 2431, 2563, 2699, 2809, 2953],
  M: [14, 26, 42, 62, 84, 106, 122, 152, 180, 213, 251, 287, 331, 362, 412, 450, 504, 560, 624, 666, 711, 779, 857, 911, 997, 1059, 1125, 1190, 1264, 1370, 1452, 1538, 1628, 1722, 1809, 1911, 1989, 2099, 2213, 2331],
  Q: [11, 20, 32, 46, 60, 74, 86, 108, 130, 151, 177, 203, 241, 258, 292, 322, 364, 394, 442, 482, 509, 565, 611, 661, 715, 751, 805, 868, 908, 982, 1030, 1112, 1168, 1228, 1283, 1351, 1423, 1499, 1579, 1663],
  H: [7, 14, 24, 34, 44, 58, 64, 84, 98, 119, 137, 155, 177, 194, 220, 250, 280, 310, 338, 382, 403, 439, 461, 511, 535, 593, 625, 658, 698, 742, 790, 842, 898, 958, 983, 1051, 1093, 1139, 1219, 1273]
};
function calculateOptimalVersion(content, ecc) {
  const caps = ECC_CAPACITIES[ecc];
  const len = content.length;
  for (let v = 0; v < caps.length; v++) {
    if (caps[v] >= len) {
      return v + 1;
    }
  }
  return 40;
}
function getVersionFromModuleCount(moduleCount) {
  return (moduleCount - 17) / 4;
}
function getAlignmentPositions(version) {
  if (version < 2 || version > 40) return [];
  return ALIGNMENT_POSITIONS2[version] || [];
}
function isLocked2(moduleCount, x, y, scale = 1) {
  const l = moduleCount / scale;
  const sx = Math.floor(x / scale);
  const sy = Math.floor(y / scale);
  if (sx < 0 || sy < 0 || sx >= l || sy >= l) return true;
  if (sx < 7 && sy < 7) return true;
  if (sx < 7 && sy > l - 8) return true;
  if (sx > l - 8 && sy < 7) return true;
  if (sx === 6 || sy === 6) return true;
  const version = getVersionFromModuleCount(l);
  const positions = getAlignmentPositions(version);
  if (positions.length > 0) {
    for (const px of positions) {
      for (const py of positions) {
        if (px < 8 && py < 8) continue;
        if (px < 8 && py > l - 9) continue;
        if (px > l - 9 && py < 8) continue;
        if (Math.abs(sx - px) <= 2 && Math.abs(sy - py) <= 2) {
          return true;
        }
      }
    }
  }
  return false;
}
function isData2(x, y, scale) {
  const m = Math.floor(scale / 2);
  const xs = x % scale;
  const ys = y % scale;
  if (xs === m && ys === m) return true;
  if (scale % 2 === 1) return false;
  if (xs === m && ys === m - 1) return true;
  if (xs === m - 1 && ys === m) return true;
  if (xs === m - 1 && ys === m - 1) return true;
  return false;
}
function generateQR(options) {
  const { text, ecc, version = 0, scale = 1 } = options;
  let typeNumber = version;
  if (typeNumber === 0) {
    typeNumber = calculateOptimalVersion(text, ecc);
  }
  const qr = qrcode_default(typeNumber, ecc);
  qr.addData(text);
  qr.make();
  const moduleCount = qr.getModuleCount();
  const scaledSize = moduleCount * scale;
  const matrix = [];
  for (let y = 0; y < scaledSize; y++) {
    const row = [];
    for (let x = 0; x < scaledSize; x++) {
      const qrX = Math.floor(x / scale);
      const qrY = Math.floor(y / scale);
      row.push(qr.isDark(qrY, qrX));
    }
    matrix.push(row);
  }
  return {
    matrix,
    moduleCount: scaledSize,
    version: typeNumber
  };
}

// src/modules/color-utils.ts
function parseHex(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  return {
    r: parseInt(hex.substr(0, 2), 16),
    g: parseInt(hex.substr(2, 2), 16),
    b: parseInt(hex.substr(4, 2), 16)
  };
}
function parseHexAlpha(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 4) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }
  const rgb = parseHex(hex.substr(0, 6));
  const a = hex.length >= 8 ? parseInt(hex.substr(6, 2), 16) / 255 : 1;
  return { ...rgb, a };
}
function parseRgbString(str) {
  const match = str.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
  if (match) {
    return {
      r: parseInt(match[1]),
      g: parseInt(match[2]),
      b: parseInt(match[3]),
      a: match[4] !== void 0 ? parseFloat(match[4]) : 1
    };
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}
function parseHslString(str) {
  const match = str.match(/hsla?\((\d+),\s*([\d.]+)%?,\s*([\d.]+)%?(?:,\s*([\d.]+))?\)/);
  if (match) {
    return {
      h: parseInt(match[1]),
      s: parseFloat(match[2]),
      l: parseFloat(match[3]),
      a: match[4] !== void 0 ? parseFloat(match[4]) : 1
    };
  }
  return { h: 0, s: 0, l: 0, a: 1 };
}
function parseColor(color) {
  color = color.trim().toLowerCase();
  if (color.startsWith("#")) {
    return parseHexAlpha(color);
  }
  if (color.startsWith("rgb")) {
    return parseRgbString(color);
  }
  if (color.startsWith("hsl")) {
    const hsl = parseHslString(color);
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    return { ...rgb, a: hsl.a };
  }
  const namedColors = {
    black: "#000000",
    white: "#ffffff",
    red: "#ff0000",
    green: "#00ff00",
    blue: "#0000ff",
    yellow: "#ffff00",
    cyan: "#00ffff",
    magenta: "#ff00ff",
    gray: "#808080",
    grey: "#808080",
    transparent: "#00000000"
  };
  if (namedColors[color]) {
    return parseHexAlpha(namedColors[color]);
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}
function rgbToHex(r, g, b) {
  const toHex = (n) => Math.round(n).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function rgbaToString(r, g, b, a) {
  return `rgba(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}, ${a})`;
}
function hslToRgb(h, s, l) {
  h /= 360;
  s /= 100;
  l /= 100;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p2, q2, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
      if (t < 1 / 2) return q2;
      if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
      return p2;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255)
  };
}
function blendColors(color1, color2, ratio) {
  const c1 = parseColor(color1);
  const c2 = parseColor(color2);
  const r = Math.round(c1.r + (c2.r - c1.r) * ratio);
  const g = Math.round(c1.g + (c2.g - c1.g) * ratio);
  const b = Math.round(c1.b + (c2.b - c1.b) * ratio);
  const a = c1.a + (c2.a - c1.a) * ratio;
  if (a < 1) {
    return rgbaToString(r, g, b, a);
  }
  return rgbToHex(r, g, b);
}

// src/modules/qr-generator.js
var defaultBrowserCanvasFactory = {
  createCanvas: (width, height) => {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    return Promise.resolve(canvas);
  },
  loadImage: (src) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = (e) => reject(new Error(`Failed to load image: ${src}`));
      img.src = src;
    });
  }
};
var QRGenerator = class {
  /**
   * Create a QR generator instance
   * @param {CanvasFactory} [canvasFactory] - Optional canvas factory for non-browser environments
   */
  constructor(canvasFactory = null) {
    this.qrcode = qrcode_default;
    this._canvasFactory = canvasFactory || defaultBrowserCanvasFactory;
  }
  /**
   * Create a canvas using the configured factory
   * @param {number} width
   * @param {number} height
   * @returns {Promise<HTMLCanvasElement|object>}
   */
  async _createCanvas(width, height) {
    return this._canvasFactory.createCanvas(width, height);
  }
  async loadLibrary() {
    return Promise.resolve();
  }
  async generate(config, overlayCanvas = null) {
    if (!this.qrcode) {
      await this.loadLibrary();
    }
    let typeNumber = config.typeNumber;
    if (typeNumber === 0) {
      typeNumber = this.calculateOptimalVersion(
        config.content,
        config.errorCorrection
      );
    }
    if (config.overlayMode === "dithered" && overlayCanvas) {
      return await this.generateDitheredSubpixelQR(
        null,
        { ...config, typeNumber },
        overlayCanvas
      );
    }
    if (config.overlayMode === "blue-noise" && overlayCanvas) {
      return await this.generateBlueNoiseQR({ ...config, typeNumber }, overlayCanvas);
    }
    const qr = this.qrcode(typeNumber, config.errorCorrection);
    qr.addData(config.content);
    qr.make();
    const moduleCount = qr.getModuleCount();
    if (config.overlayMode === "dithered" && overlayCanvas) {
      return await this.generateDitheredSubpixelQR(
        qr,
        config,
        overlayCanvas,
        moduleCount
      );
    }
    if (config.overlayMode === "subpixel" && overlayCanvas) {
      return await this.generateSubpixelQR(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        false
      );
    }
    if (config.overlayMode === "subpixel-size" && overlayCanvas) {
      return await this.generateSubpixelQR(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        true
      );
    }
    const moduleSize = config.moduleSize;
    const margin = config.margin;
    const frameExtra = config.frameStyle && config.frameStyle !== "none" && config.frameText ? moduleSize * 4 : 0;
    const size = moduleCount * moduleSize + margin * 2 * moduleSize + frameExtra;
    const canvas = await this._createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    if (!config.transparentBg) {
      ctx.fillStyle = config.bgColor;
      ctx.fillRect(0, 0, size, size);
    }
    let overlayData = null;
    if (overlayCanvas) {
      overlayData = await this._getOverlayData(
        overlayCanvas,
        moduleCount,
        config.colorMode || "color",
        config.invertImage || false
      );
    }
    let ditherPattern = null;
    if (config.overlayMode === "dither" && overlayData) {
      ditherPattern = this.applyTrueDither(qr, overlayData, config, false);
    } else if (config.overlayMode === "extreme" && overlayData) {
      ditherPattern = this.applyTrueDither(qr, overlayData, config, true);
    }
    const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
    const gradientFill = this.createGradientFill(ctx, config, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const cornerRadius = config.cornerRadius || 0;
    const dotRotation = config.dotRotationDeg || 0;
    const alignmentStyle = config.alignmentStyle || "match_finder";
    const timingStyle = config.timingStyle || "match_module";
    const drawnFinderPatterns = /* @__PURE__ */ new Set();
    const drawnAlignmentPatterns = /* @__PURE__ */ new Set();
    const finderPositions = [
      { row: 0, col: 0 },
      // Top-left
      { row: 0, col: moduleCount - 7 },
      // Top-right
      { row: moduleCount - 7, col: 0 }
      // Bottom-left
    ];
    for (const pos of finderPositions) {
      const x = (pos.col + margin) * moduleSize;
      const y = (pos.row + margin) * moduleSize;
      this.drawFinderPatternComplete(ctx, x, y, moduleSize, config);
      for (let r = pos.row; r < pos.row + 7; r++) {
        for (let c = pos.col; c < pos.col + 7; c++) {
          drawnFinderPatterns.add(`${r},${c}`);
        }
      }
    }
    if (version >= 2) {
      const alignPositions = this.getAlignmentPositions(version, moduleCount);
      for (const pos of alignPositions) {
        const centerX = (pos.col + margin) * moduleSize + moduleSize / 2;
        const centerY = (pos.row + margin) * moduleSize + moduleSize / 2;
        this.drawAlignmentPattern(ctx, centerX, centerY, moduleSize, alignmentStyle, config);
        for (let r = pos.row - 2; r <= pos.row + 2; r++) {
          for (let c = pos.col - 2; c <= pos.col + 2; c++) {
            drawnAlignmentPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        if (drawnFinderPatterns.has(`${row},${col}`)) continue;
        if (drawnAlignmentPatterns.has(`${row},${col}`)) continue;
        const isDark = ditherPattern ? ditherPattern[row][col] : qr.isDark(row, col);
        const x = (col + margin) * moduleSize;
        const y = (row + margin) * moduleSize;
        const isFinder = this.isFinderPattern(row, col, moduleCount);
        const isTiming = this.isTimingPattern(row, col, moduleCount);
        const applyOverlay = overlayData && (!config.preserveFinders || !isFinder) && (!config.preserveTiming || !isTiming);
        let moduleColor = isDark ? config.fgColor : config.bgColor;
        let moduleSizeModifier = 1;
        let moduleOpacity = 1;
        let waveOffsetX = 0;
        let waveOffsetY = 0;
        let drawOutlineOnly = false;
        let shouldDrawCell = isDark;
        if (applyOverlay) {
          const brightness = overlayData[row][col];
          switch (config.overlayMode) {
            case "halftone":
              if (isDark) {
                const intensity = config.overlayIntensity / 100;
                const minSize = 0.3;
                const maxSize = 1;
                moduleSizeModifier = minSize + (1 - brightness) * (maxSize - minSize) * intensity + (1 - intensity) * (maxSize - minSize) / 2;
              }
              break;
            case "blend":
              if (isDark) {
                const blendColor = overlayData.colors?.[row]?.[col];
                if (blendColor) {
                  const blendAmount = config.overlayIntensity / 100;
                  moduleColor = blendColors(
                    config.fgColor,
                    blendColor,
                    blendAmount
                  );
                }
              }
              break;
            case "brightness":
              if (isDark) {
                const threshold = (100 - config.overlayIntensity) / 100;
                if (brightness > threshold) {
                  moduleOpacity = 0;
                }
              }
              break;
            case "gapfill":
              if (isDark) {
                moduleColor = config.fgColor;
              } else {
                const gapColor = overlayData.colors?.[row]?.[col];
                if (gapColor) {
                  const fadeAmount = config.overlayIntensity / 100 * 0.4;
                  moduleColor = blendColors(
                    config.bgColor,
                    gapColor,
                    fadeAmount
                  );
                  shouldDrawCell = true;
                }
              }
              break;
            case "pixelate":
              if (isDark) {
                const blockSize = 3;
                const blockRow = Math.floor(row / blockSize) * blockSize;
                const blockCol = Math.floor(col / blockSize) * blockSize;
                let avgR = 0, avgG = 0, avgB = 0, pixCount = 0;
                for (let br = 0; br < blockSize && blockRow + br < moduleCount; br++) {
                  for (let bc = 0; bc < blockSize && blockCol + bc < moduleCount; bc++) {
                    const c = overlayData.colors?.[blockRow + br]?.[blockCol + bc];
                    if (c) {
                      const parsed = parseColor(c);
                      avgR += parsed.r;
                      avgG += parsed.g;
                      avgB += parsed.b;
                      pixCount++;
                    }
                  }
                }
                if (pixCount > 0) {
                  avgR = Math.round(avgR / pixCount);
                  avgG = Math.round(avgG / pixCount);
                  avgB = Math.round(avgB / pixCount);
                  const blockColor = `rgb(${avgR},${avgG},${avgB})`;
                  const pixBlendAmt = config.overlayIntensity / 100;
                  moduleColor = blendColors(
                    config.fgColor,
                    blockColor,
                    pixBlendAmt
                  );
                }
              }
              break;
            case "duotone":
              if (isDark) {
                const duotoneArr = config.duotoneColors || [];
                const shadowColor = duotoneArr[0] || config.fgColor;
                const highlightColor = duotoneArr[1] || null;
                const intensity = config.overlayIntensity / 100;
                if (brightness > 0.5) {
                  if (highlightColor) {
                    moduleColor = blendColors(config.fgColor, highlightColor, intensity * (brightness - 0.5) * 2);
                  } else {
                    const fgParsed = parseColor(config.fgColor);
                    const lightR = Math.min(255, fgParsed.r + 80);
                    const lightG = Math.min(255, fgParsed.g + 80);
                    const lightB = Math.min(255, fgParsed.b + 80);
                    moduleColor = `rgb(${lightR},${lightG},${lightB})`;
                  }
                } else {
                  moduleColor = blendColors(config.fgColor, shadowColor, intensity * (0.5 - brightness) * 2);
                }
              }
              break;
            case "outline":
              if (isDark) {
                drawOutlineOnly = true;
                const outlineColor = overlayData.colors?.[row]?.[col];
                if (outlineColor) {
                  const outlineBlend = config.overlayIntensity / 100;
                  moduleColor = blendColors(
                    config.fgColor,
                    outlineColor,
                    outlineBlend
                  );
                }
              }
              break;
            case "wave":
              if (isDark) {
                const waveAmt = (1 - brightness) * (config.overlayIntensity / 100) * 3;
                waveOffsetX = Math.sin(row * 0.5) * waveAmt;
                waveOffsetY = Math.cos(col * 0.5) * waveAmt;
              }
              break;
            case "mosaic": {
              shouldDrawCell = true;
              const mosaicColor = overlayData.colors?.[row]?.[col];
              if (mosaicColor) {
                const intensity = config.overlayIntensity / 100;
                if (isDark) {
                  const parsed = parseColor(mosaicColor);
                  const darkFactor = 0.7;
                  moduleColor = `rgb(${Math.round(parsed.r * darkFactor)},${Math.round(parsed.g * darkFactor)},${Math.round(parsed.b * darkFactor)})`;
                } else {
                  const parsed = parseColor(mosaicColor);
                  const lightFactor = 0.4 + (1 - intensity) * 0.4;
                  const lightR = Math.round(
                    255 - (255 - parsed.r) * lightFactor
                  );
                  const lightG = Math.round(
                    255 - (255 - parsed.g) * lightFactor
                  );
                  const lightB = Math.round(
                    255 - (255 - parsed.b) * lightFactor
                  );
                  moduleColor = `rgb(${lightR},${lightG},${lightB})`;
                }
              }
              break;
            }
          }
        }
        if (shouldDrawCell && moduleOpacity > 0) {
          ctx.save();
          ctx.globalAlpha = moduleOpacity;
          if (isDark && useGradient) {
            ctx.fillStyle = gradientFill;
          } else {
            ctx.fillStyle = moduleColor;
          }
          let gap = config.moduleGap ? moduleSize * config.moduleGap / 100 : 0;
          const gapMode = config.gapMode || "none";
          let strokeWidth = 0;
          if (gapMode === "inset") {
            gap = Math.max(gap, moduleSize * 0.1);
          } else if (gapMode === "stroke") {
            strokeWidth = Math.max(1, moduleSize * 0.15);
            gap = strokeWidth;
          } else if (gapMode === "negative_space") {
            gap = Math.max(gap, moduleSize * 0.2);
          }
          const adjustedSize = (moduleSize - gap) * moduleSizeModifier;
          const offset = (moduleSize - adjustedSize) / 2;
          let drawX = x + offset + waveOffsetX;
          let drawY = y + offset + waveOffsetY;
          const pixelSnap = config.pixelSnap || "floor";
          if (pixelSnap === "floor") {
            drawX = Math.floor(drawX);
            drawY = Math.floor(drawY);
          } else if (pixelSnap === "round") {
            drawX = Math.round(drawX);
            drawY = Math.round(drawY);
          } else if (pixelSnap === "ceil") {
            drawX = Math.ceil(drawX);
            drawY = Math.ceil(drawY);
          }
          if (drawOutlineOnly || gapMode === "stroke" && isDark) {
            ctx.strokeStyle = moduleColor;
            ctx.lineWidth = strokeWidth || 1;
            ctx.strokeRect(drawX + ctx.lineWidth / 2, drawY + ctx.lineWidth / 2, adjustedSize - ctx.lineWidth, adjustedSize - ctx.lineWidth);
          } else if (isTiming) {
            this.drawTimingModule(ctx, drawX, drawY, adjustedSize, timingStyle, config);
          } else {
            this.drawModule(
              ctx,
              drawX,
              drawY,
              adjustedSize,
              config.moduleStyle,
              { cornerRadius, rotation: dotRotation }
            );
          }
          ctx.restore();
        }
      }
    }
    if (overlayCanvas && config.overlayMode === "center") {
      this.drawCenterLogo(ctx, overlayCanvas, size, config.logoSize);
    }
    this.drawFrame(ctx, size, moduleSize, margin, config);
    return canvas;
  }
  calculateOptimalVersion(content, errorCorrection) {
    const capacities = {
      L: [
        17,
        32,
        53,
        78,
        106,
        134,
        154,
        192,
        230,
        271,
        321,
        367,
        425,
        458,
        520,
        586,
        644,
        718,
        792,
        858,
        929,
        1003,
        1091,
        1171,
        1273,
        1367,
        1465,
        1528,
        1628,
        1732,
        1840,
        1952,
        2068,
        2188,
        2303,
        2431,
        2563,
        2699,
        2809,
        2953
      ],
      M: [
        14,
        26,
        42,
        62,
        84,
        106,
        122,
        152,
        180,
        213,
        251,
        287,
        331,
        362,
        412,
        450,
        504,
        560,
        624,
        666,
        711,
        779,
        857,
        911,
        997,
        1059,
        1125,
        1190,
        1264,
        1370,
        1452,
        1538,
        1628,
        1722,
        1809,
        1911,
        1989,
        2099,
        2213,
        2331
      ],
      Q: [
        11,
        20,
        32,
        46,
        60,
        74,
        86,
        108,
        130,
        151,
        177,
        203,
        241,
        258,
        292,
        322,
        364,
        394,
        442,
        482,
        509,
        565,
        611,
        661,
        715,
        751,
        805,
        868,
        908,
        982,
        1030,
        1112,
        1168,
        1228,
        1283,
        1351,
        1423,
        1499,
        1579,
        1663
      ],
      H: [
        7,
        14,
        24,
        34,
        44,
        58,
        64,
        84,
        98,
        119,
        137,
        155,
        177,
        194,
        220,
        250,
        280,
        310,
        338,
        382,
        403,
        439,
        461,
        511,
        535,
        593,
        625,
        658,
        698,
        742,
        790,
        842,
        898,
        958,
        983,
        1051,
        1093,
        1139,
        1219,
        1273
      ]
    };
    const caps = capacities[errorCorrection] || capacities["Q"];
    const len = content.length;
    for (let v = 0; v < caps.length; v++) {
      if (caps[v] >= len) {
        return v + 1;
      }
    }
    return 40;
  }
  isFinderPattern(row, col, moduleCount) {
    if (row < 7 && col < 7) return true;
    if (row < 7 && col >= moduleCount - 7) return true;
    if (row >= moduleCount - 7 && col < 7) return true;
    return false;
  }
  /**
   * Check if a module is part of a timing pattern
   */
  isTimingPattern(row, col, moduleCount) {
    if (row === 6 && col >= 8 && col < moduleCount - 8) return true;
    if (col === 6 && row >= 8 && row < moduleCount - 8) return true;
    return false;
  }
  /**
   * Check if a module is part of an alignment pattern
   */
  isAlignmentPattern(row, col, moduleCount, version) {
    if (version < 2) return false;
    const positions = this.getAlignmentPositions(version, moduleCount);
    for (const pos of positions) {
      if (Math.abs(row - pos.row) <= 2 && Math.abs(col - pos.col) <= 2) {
        return true;
      }
    }
    return false;
  }
  /**
   * Get the center position of an alignment pattern if this module is part of one
   */
  getAlignmentCenter(row, col, moduleCount, version) {
    if (version < 2) return null;
    const positions = this.getAlignmentPositions(version, moduleCount);
    for (const pos of positions) {
      if (Math.abs(row - pos.row) <= 2 && Math.abs(col - pos.col) <= 2) {
        return pos;
      }
    }
    return null;
  }
  /**
   * Check if a module is a structural element that cannot be modified
   */
  isStructuralModule(row, col, moduleCount, version) {
    if (row < 8 && col < 8) return true;
    if (row < 8 && col >= moduleCount - 8) return true;
    if (row >= moduleCount - 8 && col < 8) return true;
    if (row === 6 || col === 6) return true;
    if (row === 8 && col < 9) return true;
    if (col === 8 && row < 9) return true;
    if (row === 8 && col >= moduleCount - 8) return true;
    if (col === 8 && row >= moduleCount - 8) return true;
    if (row === moduleCount - 8 && col === 8) return true;
    if (version >= 7) {
      if (row >= moduleCount - 11 && row < moduleCount - 8 && col < 6)
        return true;
      if (col >= moduleCount - 11 && col < moduleCount - 8 && row < 6)
        return true;
    }
    if (version >= 2) {
      const positions = this.getAlignmentPositions(version, moduleCount);
      for (const pos of positions) {
        if (Math.abs(row - pos.row) <= 2 && Math.abs(col - pos.col) <= 2)
          return true;
      }
    }
    return false;
  }
  getAlignmentPositions(version, moduleCount) {
    if (version < 2) return [];
    const table = {
      2: [6, 18],
      3: [6, 22],
      4: [6, 26],
      5: [6, 30],
      6: [6, 34],
      7: [6, 22, 38],
      8: [6, 24, 42],
      9: [6, 26, 46],
      10: [6, 28, 50],
      11: [6, 30, 54],
      12: [6, 32, 58],
      13: [6, 34, 62],
      14: [6, 26, 46, 66],
      15: [6, 26, 48, 70],
      16: [6, 26, 50, 74],
      17: [6, 30, 54, 78],
      18: [6, 30, 56, 82],
      19: [6, 30, 58, 86],
      20: [6, 34, 62, 90],
      21: [6, 28, 50, 72, 94],
      22: [6, 26, 50, 74, 98],
      23: [6, 30, 54, 78, 102],
      24: [6, 28, 54, 80, 106],
      25: [6, 32, 58, 84, 110],
      26: [6, 30, 58, 86, 114],
      27: [6, 34, 62, 90, 118],
      28: [6, 26, 50, 74, 98, 122],
      29: [6, 30, 54, 78, 102, 126],
      30: [6, 26, 52, 78, 104, 130],
      31: [6, 30, 56, 82, 108, 134],
      32: [6, 34, 60, 86, 112, 138],
      33: [6, 30, 58, 86, 114, 142],
      34: [6, 34, 62, 90, 118, 146],
      35: [6, 30, 54, 78, 102, 126, 150],
      36: [6, 24, 50, 76, 102, 128, 154],
      37: [6, 28, 54, 80, 106, 132, 158],
      38: [6, 32, 58, 84, 110, 136, 162],
      39: [6, 26, 54, 82, 110, 138, 166],
      40: [6, 30, 58, 86, 114, 142, 170]
    };
    const coords = table[version] || [6];
    const positions = [];
    for (const r of coords) {
      for (const c of coords) {
        if (r < 8 && c < 8) continue;
        if (r < 8 && c > moduleCount - 9) continue;
        if (r > moduleCount - 9 && c < 8) continue;
        positions.push({ row: r, col: c });
      }
    }
    return positions;
  }
  applyTrueDither(qr, overlayData, config, extremeMode = false) {
    const moduleCount = qr.getModuleCount();
    const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
    const modifiedPattern = [];
    for (let row = 0; row < moduleCount; row++) {
      modifiedPattern[row] = [];
      for (let col = 0; col < moduleCount; col++) {
        modifiedPattern[row][col] = qr.isDark(row, col);
      }
    }
    if (extremeMode) {
      for (let row = 0; row < moduleCount; row++) {
        for (let col = 0; col < moduleCount; col++) {
          if (this.isFinderPattern(row, col, moduleCount)) continue;
          const brightness = overlayData[row]?.[col] ?? 0.5;
          const intensity = config.overlayIntensity / 100;
          const desiredDark = brightness < 0.5;
          if (intensity >= 1 || Math.random() < intensity) {
            modifiedPattern[row][col] = desiredDark;
          }
        }
      }
    } else {
      const ecCapacity = { L: 0.07, M: 0.15, Q: 0.25, H: 0.3 };
      const maxFlipRatio = ecCapacity[config.errorCorrection] || 0.25;
      const intensity = config.overlayIntensity / 100;
      let totalDataModules = 0;
      const flipCandidates = [];
      for (let row = 0; row < moduleCount; row++) {
        for (let col = 0; col < moduleCount; col++) {
          if (this.isStructuralModule(row, col, moduleCount, version)) continue;
          totalDataModules++;
          const currentState = qr.isDark(row, col);
          const brightness = overlayData[row]?.[col] ?? 0.5;
          const desiredState = brightness < 0.5;
          if (currentState !== desiredState) {
            flipCandidates.push({
              row,
              col,
              score: Math.abs(brightness - 0.5),
              desiredState
            });
          }
        }
      }
      flipCandidates.sort((a, b) => b.score - a.score);
      const maxFlips = Math.floor(totalDataModules * maxFlipRatio * intensity);
      for (let i = 0; i < Math.min(flipCandidates.length, maxFlips); i++) {
        const c = flipCandidates[i];
        modifiedPattern[c.row][c.col] = c.desiredState;
      }
    }
    return modifiedPattern;
  }
  /**
   * Draw a single module with support for style, corner radius, and rotation
   */
  drawModule(ctx, x, y, size, style, options = {}) {
    const { cornerRadius = 0, rotation = 0 } = options;
    const padding = size * 0.05;
    const innerSize = size - padding * 2;
    const radiusPercent = cornerRadius / 100;
    const maxRadius = innerSize / 2;
    const actualRadius = maxRadius * radiusPercent;
    ctx.save();
    if (rotation !== 0) {
      const centerX = x + size / 2;
      const centerY = y + size / 2;
      ctx.translate(centerX, centerY);
      ctx.rotate(rotation * Math.PI / 180);
      ctx.translate(-centerX, -centerY);
    }
    switch (style) {
      case "rounded":
        const roundedRadius = actualRadius > 0 ? actualRadius : size * 0.3;
        this.roundRect(
          ctx,
          x + padding,
          y + padding,
          innerSize,
          innerSize,
          roundedRadius
        );
        ctx.fill();
        break;
      case "dots":
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, innerSize / 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      case "diamond":
        ctx.beginPath();
        ctx.moveTo(x + size / 2, y + padding);
        ctx.lineTo(x + size - padding, y + size / 2);
        ctx.lineTo(x + size / 2, y + size - padding);
        ctx.lineTo(x + padding, y + size / 2);
        ctx.closePath();
        ctx.fill();
        break;
      case "connected":
        if (actualRadius > 0) {
          this.roundRect(ctx, x, y, size, size, actualRadius);
          ctx.fill();
        } else {
          ctx.fillRect(x, y, size, size);
        }
        break;
      case "square":
      default:
        if (actualRadius > 0) {
          this.roundRect(ctx, x + padding, y + padding, innerSize, innerSize, actualRadius);
          ctx.fill();
        } else {
          ctx.fillRect(x + padding, y + padding, innerSize, innerSize);
        }
        break;
    }
    ctx.restore();
  }
  /**
   * Draw a single finder pattern module
   */
  drawFinderModule(ctx, x, y, size, style, cornerRadius = 0) {
    const radiusPercent = cornerRadius / 100;
    const maxRadius = size / 2;
    const actualRadius = maxRadius * radiusPercent;
    switch (style) {
      case "rounded":
        const roundedRadius = actualRadius > 0 ? actualRadius : size * 0.2;
        this.roundRect(ctx, x, y, size, size, roundedRadius);
        ctx.fill();
        break;
      case "circle":
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      case "square":
      default:
        if (actualRadius > 0) {
          this.roundRect(ctx, x, y, size, size, actualRadius);
          ctx.fill();
        } else {
          ctx.fillRect(x, y, size, size);
        }
        break;
    }
  }
  /**
   * Draw a complete finder pattern (eye) with outer and inner styles
   */
  drawFinderPatternComplete(ctx, centerX, centerY, moduleSize, config) {
    const outerStyle = config.eyeOuterStyle || config.finderStyle || "square";
    const innerStyle = config.eyeInnerStyle || config.finderStyle || "square";
    const scale = (config.eyeScale || 100) / 100;
    const cornerRadius = config.cornerRadius || 0;
    const outerSize = 7 * moduleSize * scale;
    const middleSize = 5 * moduleSize * scale;
    const innerSize = 3 * moduleSize * scale;
    const outerOffset = (7 * moduleSize - outerSize) / 2;
    const x = centerX + outerOffset;
    const y = centerY + outerOffset;
    ctx.fillStyle = config.fgColor;
    this.drawFinderModule(ctx, x, y, outerSize, outerStyle, cornerRadius);
    ctx.fillStyle = config.bgColor;
    const middleOffset = (outerSize - middleSize) / 2;
    this.drawFinderModule(ctx, x + middleOffset, y + middleOffset, middleSize, outerStyle, cornerRadius);
    ctx.fillStyle = config.fgColor;
    const innerOffset = (outerSize - innerSize) / 2;
    this.drawFinderModule(ctx, x + innerOffset, y + innerOffset, innerSize, innerStyle, cornerRadius);
  }
  /**
   * Draw an alignment pattern with specified style
   */
  drawAlignmentPattern(ctx, centerX, centerY, moduleSize, style, config) {
    const cornerRadius = config.cornerRadius || 0;
    const outerSize = 5 * moduleSize;
    const middleSize = 3 * moduleSize;
    const innerSize = 1 * moduleSize;
    const x = centerX - outerSize / 2;
    const y = centerY - outerSize / 2;
    const effectiveStyle = style === "match_finder" ? config.finderStyle || "square" : style;
    ctx.fillStyle = config.fgColor;
    this.drawFinderModule(ctx, x, y, outerSize, effectiveStyle, cornerRadius);
    ctx.fillStyle = config.bgColor;
    const middleX = centerX - middleSize / 2;
    const middleY = centerY - middleSize / 2;
    this.drawFinderModule(ctx, middleX, middleY, middleSize, effectiveStyle, cornerRadius);
    ctx.fillStyle = config.fgColor;
    const innerX = centerX - innerSize / 2;
    const innerY = centerY - innerSize / 2;
    this.drawFinderModule(ctx, innerX, innerY, innerSize, effectiveStyle, cornerRadius);
  }
  /**
   * Draw timing pattern with specified style
   */
  drawTimingModule(ctx, x, y, size, style, config) {
    const cornerRadius = config.cornerRadius || 0;
    const effectiveStyle = style === "match_module" ? config.moduleStyle || "square" : style;
    switch (effectiveStyle) {
      case "solid":
        ctx.fillRect(x, y, size, size);
        break;
      case "dashed":
        const dashSize = size * 0.7;
        const offset = (size - dashSize) / 2;
        ctx.fillRect(x + offset, y + offset, dashSize, dashSize);
        break;
      default:
        this.drawModule(ctx, x, y, size, effectiveStyle, { cornerRadius });
    }
  }
  /**
   * Create a gradient fill style based on config
   */
  createGradientFill(ctx, config, size) {
    if (!config.gradient || config.gradient.type === "none") {
      return config.fgColor;
    }
    const { type, stops, centerX = 0.5, centerY = 0.5 } = config.gradient;
    const angle = config.gradient.angle || 0;
    let gradient;
    switch (type) {
      case "linear": {
        const angleRad = angle * Math.PI / 180;
        const x1 = size / 2 - Math.cos(angleRad) * size / 2;
        const y1 = size / 2 - Math.sin(angleRad) * size / 2;
        const x2 = size / 2 + Math.cos(angleRad) * size / 2;
        const y2 = size / 2 + Math.sin(angleRad) * size / 2;
        gradient = ctx.createLinearGradient(x1, y1, x2, y2);
        break;
      }
      case "radial": {
        const cx = size * (centerX || 0.5);
        const cy = size * (centerY || 0.5);
        const radius = size * 0.7;
        gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
        break;
      }
      case "conic": {
        const cx = size * (centerX || 0.5);
        const cy = size * (centerY || 0.5);
        gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, size * 0.7);
        break;
      }
      default:
        return config.fgColor;
    }
    if (stops && stops.length > 0) {
      stops.forEach((stop) => {
        gradient.addColorStop(stop.pos, stop.color);
      });
    } else {
      gradient.addColorStop(0, config.fgColor);
      gradient.addColorStop(1, config.bgColor);
    }
    return gradient;
  }
  /**
   * Draw a decorative frame around the QR code
   */
  drawFrame(ctx, size, moduleSize, margin, config) {
    const frameStyle = config.frameStyle;
    if (!frameStyle || frameStyle === "none") return;
    const frameText = config.frameText || "";
    const qrSize = size - margin * 2 * moduleSize - (frameText ? moduleSize * 4 : 0);
    const qrStart = margin * moduleSize;
    ctx.save();
    switch (frameStyle) {
      case "rounded_frame": {
        ctx.strokeStyle = config.fgColor;
        ctx.lineWidth = moduleSize * 0.5;
        const frameMargin = moduleSize;
        this.roundRect(
          ctx,
          qrStart - frameMargin,
          qrStart - frameMargin,
          qrSize + frameMargin * 2,
          qrSize + frameMargin * 2 + (frameText ? moduleSize * 3 : 0),
          moduleSize * 2
        );
        ctx.stroke();
        break;
      }
      case "sticker": {
        ctx.shadowColor = "rgba(0,0,0,0.2)";
        ctx.shadowBlur = moduleSize * 2;
        ctx.shadowOffsetX = moduleSize * 0.5;
        ctx.shadowOffsetY = moduleSize * 0.5;
        ctx.fillStyle = config.bgColor;
        const stickerPadding = moduleSize * 1.5;
        this.roundRect(
          ctx,
          qrStart - stickerPadding,
          qrStart - stickerPadding,
          qrSize + stickerPadding * 2,
          qrSize + stickerPadding * 2 + (frameText ? moduleSize * 4 : 0),
          moduleSize * 3
        );
        ctx.fill();
        ctx.shadowColor = "transparent";
        break;
      }
      case "tag": {
        ctx.fillStyle = config.fgColor;
        const tagPadding = moduleSize;
        const tagWidth = qrSize + tagPadding * 2;
        const tagHeight = qrSize + tagPadding * 2 + (frameText ? moduleSize * 4 : 0);
        const tagX = qrStart - tagPadding;
        const tagY = qrStart - tagPadding;
        ctx.beginPath();
        ctx.moveTo(tagX + moduleSize, tagY);
        ctx.lineTo(tagX + tagWidth - moduleSize, tagY);
        ctx.quadraticCurveTo(tagX + tagWidth, tagY, tagX + tagWidth, tagY + moduleSize);
        ctx.lineTo(tagX + tagWidth, tagY + tagHeight - moduleSize);
        ctx.quadraticCurveTo(tagX + tagWidth, tagY + tagHeight, tagX + tagWidth - moduleSize, tagY + tagHeight);
        ctx.lineTo(tagX + moduleSize, tagY + tagHeight);
        ctx.quadraticCurveTo(tagX, tagY + tagHeight, tagX, tagY + tagHeight - moduleSize);
        ctx.lineTo(tagX, tagY + moduleSize);
        ctx.quadraticCurveTo(tagX, tagY, tagX + moduleSize, tagY);
        ctx.closePath();
        ctx.stroke();
        break;
      }
    }
    if (frameText) {
      ctx.fillStyle = config.fgColor;
      ctx.font = `bold ${moduleSize * 2}px Arial, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      const textY = qrStart + qrSize + moduleSize * 1.5;
      ctx.fillText(frameText, size / 2, textY);
    }
    ctx.restore();
  }
  roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }
  /**
   * Get overlay data - async version using canvas factory
   * @private
   */
  async _getOverlayData(overlayCanvas, moduleCount, colorMode = "color", invertImage = false) {
    const tempCanvas = await this._createCanvas(moduleCount, moduleCount);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(overlayCanvas, 0, 0, moduleCount, moduleCount);
    const imageData = ctx.getImageData(0, 0, moduleCount, moduleCount);
    const data = imageData.data;
    const brightness = [];
    const colors = [];
    for (let row = 0; row < moduleCount; row++) {
      brightness[row] = [];
      colors[row] = [];
      for (let col = 0; col < moduleCount; col++) {
        const i = (row * moduleCount + col) * 4;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const gray = Math.round(r * 0.299 + g * 0.587 + b * 0.114);
        brightness[row][col] = gray / 255;
        if (colorMode === "bw") {
          const bw = gray > 127 ? 255 : 0;
          colors[row][col] = `rgb(${bw},${bw},${bw})`;
        } else if (colorMode === "grayscale") {
          colors[row][col] = `rgb(${gray},${gray},${gray})`;
        } else {
          colors[row][col] = `rgb(${r},${g},${b})`;
        }
      }
    }
    brightness.colors = colors;
    return brightness;
  }
  // blendColors and parseColor are now imported from ./color-utils.ts
  drawCenterLogo(ctx, logoCanvas, canvasSize, logoSizePercent) {
    const logoSize = canvasSize * (logoSizePercent / 100);
    const x = (canvasSize - logoSize) / 2;
    const y = (canvasSize - logoSize) / 2;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(x - 4, y - 4, logoSize + 8, logoSize + 8);
    ctx.drawImage(logoCanvas, x, y, logoSize, logoSize);
  }
  /**
   * Generate a "dithered QR code" style render based on the TypeScript reference
   * implementation from https://codeberg.org/andrew-t/dithered-qr-codes.
   *
   * Notes:
   * - We render a 3x (subpixel) grid per QR module.
   * - Locked areas (finders, timing lines, alignments) are preserved.
   * - Free pixels are set from the image via error diffusion.
   * - Supports color, grayscale, and B&W modes for higher fidelity.
   */
  async generateDitheredSubpixelQR(_qr, config, overlayCanvas) {
    const scale = 3;
    const qrResult = generateQR({
      text: config.content,
      ecc: config.errorCorrection,
      version: config.typeNumber || 0,
      scale
    });
    const { matrix: baseMatrix, moduleCount: scaledSize } = qrResult;
    const ditheredResult = await this._applyDitherToMatrix(
      baseMatrix,
      scaledSize,
      scale,
      overlayCanvas,
      config.overlayIntensity,
      config.colorMode || "color"
    );
    const { matrix: dithered, colors } = ditheredResult;
    const scaledCount = dithered.length;
    const derivedModuleCount = Math.round(scaledCount / scale);
    const marginModules = Math.max(5, config.margin);
    const subPixelSize = Math.max(1, Math.round(config.moduleSize / scale));
    const effectiveModuleSize = subPixelSize * scale;
    const marginPx = marginModules * effectiveModuleSize;
    const size = scaledCount * subPixelSize + marginPx * 2;
    const pixelSize = subPixelSize;
    const canvas = await this._createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    if (!config.transparentBg) {
      ctx.fillStyle = config.bgColor;
      ctx.fillRect(0, 0, size, size);
    }
    const useColorRendering = overlayCanvas && config.colorMode !== "bw";
    for (let y = 0; y < scaledCount; y++) {
      for (let x = 0; x < scaledCount; x++) {
        const isDark = dithered[y][x];
        const color = colors[y][x];
        if (!isDark && !useColorRendering) continue;
        const dx = marginPx + x * pixelSize;
        const dy = marginPx + y * pixelSize;
        if (useColorRendering) {
          ctx.fillStyle = `rgb(${color.r},${color.g},${color.b})`;
          ctx.fillRect(dx, dy, pixelSize, pixelSize);
        } else {
          if (isDark) {
            ctx.fillStyle = config.fgColor;
            ctx.fillRect(dx, dy, pixelSize, pixelSize);
          }
        }
      }
    }
    return canvas;
  }
  /**
   * Generate QR with blue-noise dithering
   * Returns a single canvas (consistent with other blend modes)
   *
   * Features:
   * - Blue-noise dithering for high-quality image representation
   * - Data points preserved for QR scannability (same approach as error diffusion)
   * - Only free points are dithered using blue noise threshold
   * - Intensity slider controls blend between QR and image
   */
  async generateBlueNoiseQR(config, overlayCanvas) {
    const scale = 3;
    const blueNoiseResult = generateBlueNoiseDithered({
      text: config.content,
      ecc: config.errorCorrection,
      version: config.typeNumber || 0,
      scale,
      overlayCanvas,
      overlayIntensity: config.overlayIntensity,
      colorMode: config.colorMode || "color"
    });
    const { matrix: dithered, colors } = blueNoiseResult;
    const scaledCount = dithered.length;
    const marginModules = Math.max(5, config.margin);
    const subPixelSize = Math.max(1, Math.round(config.moduleSize / scale));
    const effectiveModuleSize = subPixelSize * scale;
    const marginPx = marginModules * effectiveModuleSize;
    const size = scaledCount * subPixelSize + marginPx * 2;
    const pixelSize = subPixelSize;
    const canvas = await this._createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    if (!config.transparentBg) {
      ctx.fillStyle = config.bgColor;
      ctx.fillRect(0, 0, size, size);
    }
    const useColorRendering = overlayCanvas && config.colorMode !== "bw";
    for (let y = 0; y < scaledCount; y++) {
      for (let x = 0; x < scaledCount; x++) {
        const isDark = dithered[y][x];
        const color = colors[y][x];
        if (!isDark && !useColorRendering) continue;
        const dx = marginPx + x * pixelSize;
        const dy = marginPx + y * pixelSize;
        if (useColorRendering) {
          ctx.fillStyle = `rgb(${color.r},${color.g},${color.b})`;
          ctx.fillRect(dx, dy, pixelSize, pixelSize);
        } else {
          if (isDark) {
            ctx.fillStyle = config.fgColor;
            ctx.fillRect(dx, dy, pixelSize, pixelSize);
          }
        }
      }
    }
    return canvas;
  }
  /**
   * Generate QR with qrmove-style 3x3 subpixel rendering
   * Each QR module becomes a 3x3 grid:
   * - CENTER pixel (1,1) = QR data (must stay correct for scanning)
   * - 8 SURROUNDING pixels = freely show overlay image
   * This allows ~89% of pixels to show the image while maintaining 100% scannability
   */
  async generateSubpixelQR(qr, config, overlayCanvas, moduleCount, useHalftoneCenter = false) {
    const gridSizeStr = config.subpixelGridSize || "3x3";
    const subpixelSize = parseInt(gridSizeStr.charAt(0)) || 3;
    const margin = config.margin;
    const pixelSize = config.moduleSize / subpixelSize;
    const canvasModules = moduleCount * subpixelSize;
    const marginPixels = margin * config.moduleSize;
    const size = canvasModules * pixelSize + marginPixels * 2;
    const canvas = await this._createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    if (!config.transparentBg) {
      ctx.fillStyle = config.bgColor;
      ctx.fillRect(0, 0, size, size);
    }
    const overlayData = await this._getSubpixelOverlayData(
      overlayCanvas,
      moduleCount * subpixelSize,
      config.colorMode || "color"
    );
    const moduleBrightness = await this._getOverlayData(overlayCanvas, moduleCount);
    const intensity = config.overlayIntensity / 100;
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        const isDark = qr.isDark(row, col);
        const isFinder = this.isFinderPattern(row, col, moduleCount);
        const baseX = marginPixels + col * subpixelSize * pixelSize;
        const baseY = marginPixels + row * subpixelSize * pixelSize;
        if (isFinder) {
          ctx.fillStyle = isDark ? config.fgColor : config.bgColor;
          ctx.fillRect(
            baseX,
            baseY,
            subpixelSize * pixelSize,
            subpixelSize * pixelSize
          );
          continue;
        }
        for (let subRow = 0; subRow < subpixelSize; subRow++) {
          for (let subCol = 0; subCol < subpixelSize; subCol++) {
            const subX = baseX + subCol * pixelSize;
            const subY = baseY + subRow * pixelSize;
            const overlayRow = row * subpixelSize + subRow;
            const overlayCol = col * subpixelSize + subCol;
            const overlayColor = overlayData.colors?.[overlayRow]?.[overlayCol];
            if (subRow === 1 && subCol === 1) {
              if (useHalftoneCenter && isDark) {
                const brightness = moduleBrightness[row]?.[col] ?? 0.5;
                const minSize = 0.4;
                const maxSize = 1;
                const sizeRatio = minSize + (1 - brightness) * (maxSize - minSize) * intensity;
                const centerSize = pixelSize * sizeRatio;
                const offset = (pixelSize - centerSize) / 2;
                ctx.fillStyle = config.bgColor;
                ctx.fillRect(subX, subY, pixelSize, pixelSize);
                ctx.fillStyle = config.fgColor;
                ctx.fillRect(
                  subX + offset,
                  subY + offset,
                  centerSize,
                  centerSize
                );
              } else {
                ctx.fillStyle = isDark ? config.fgColor : config.bgColor;
                ctx.fillRect(subX, subY, pixelSize, pixelSize);
              }
            } else {
              if (overlayColor && intensity > 0) {
                if (intensity >= 1) {
                  ctx.fillStyle = overlayColor;
                } else {
                  ctx.fillStyle = blendColors(
                    "#808080",
                    overlayColor,
                    intensity
                  );
                }
              } else {
                ctx.fillStyle = isDark ? "#404040" : "#c0c0c0";
              }
              ctx.fillRect(subX, subY, pixelSize, pixelSize);
            }
          }
        }
      }
    }
    return canvas;
  }
  /**
   * Apply dithering to a QR matrix with overlay image
   * Uses Floyd-Steinberg error diffusion for free points
   * Supports serpentine scanning for better quality
   */
  /**
   * Apply dithering to QR matrix - async version using canvas factory
   * @private
   */
  async _applyDitherToMatrix(baseMatrix, scaledSize, scale, overlayCanvas, overlayIntensity, colorMode, serpentine = false) {
    const matrix = baseMatrix.map((row) => [...row]);
    const colors = baseMatrix.map((row) => row.map(
      (isDark) => isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 }
    ));
    if (!overlayCanvas) {
      return { matrix, colors };
    }
    const imageData = await this._loadImageDataRGB(overlayCanvas, scaledSize);
    const intensity = overlayIntensity / 100;
    if (colorMode === "grayscale" || colorMode === "bw") {
      for (let y = 0; y < scaledSize; y++) {
        for (let x = 0; x < scaledSize; x++) {
          const { r, g, b } = imageData[y][x];
          const gray = r * 0.299 + g * 0.587 + b * 0.114;
          imageData[y][x] = { r: gray, g: gray, b: gray };
        }
      }
    }
    for (let y = 0; y < scaledSize; y++) {
      const leftToRight = !serpentine || y % 2 === 0;
      const xStart = leftToRight ? 0 : scaledSize - 1;
      const xEnd = leftToRight ? scaledSize : -1;
      const xStep = leftToRight ? 1 : -1;
      for (let x = xStart; x !== xEnd; x += xStep) {
        if (isLocked2(scaledSize, x, y, scale)) continue;
        if (isData2(x, y, scale)) continue;
        const pixel = imageData[y][x];
        if (colorMode === "bw") {
          const gray = pixel.r * 0.299 + pixel.g * 0.587 + pixel.b * 0.114;
          const newVal = gray > 0.5 ? 1 : 0;
          const error = gray - newVal;
          imageData[y][x] = { r: newVal, g: newVal, b: newVal };
          this.distributeError(imageData, x, y, scaledSize, scale, error, error, error);
        } else if (colorMode === "grayscale") {
          const gray = pixel.r;
          const levels = 4;
          const newVal = Math.round(gray * (levels - 1)) / (levels - 1);
          const error = gray - newVal;
          imageData[y][x] = { r: newVal, g: newVal, b: newVal };
          this.distributeError(imageData, x, y, scaledSize, scale, error, error, error, leftToRight);
        } else {
          const levels = 4;
          const newR = Math.round(pixel.r * (levels - 1)) / (levels - 1);
          const newG = Math.round(pixel.g * (levels - 1)) / (levels - 1);
          const newB = Math.round(pixel.b * (levels - 1)) / (levels - 1);
          const errorR = pixel.r - newR;
          const errorG = pixel.g - newG;
          const errorB = pixel.b - newB;
          imageData[y][x] = { r: newR, g: newG, b: newB };
          this.distributeError(imageData, x, y, scaledSize, scale, errorR, errorG, errorB, leftToRight);
        }
      }
    }
    for (let y = 0; y < scaledSize; y++) {
      for (let x = 0; x < scaledSize; x++) {
        if (isLocked2(scaledSize, x, y, scale)) continue;
        if (isData2(x, y, scale)) continue;
        const pixel = imageData[y][x];
        const brightness = pixel.r * 0.299 + pixel.g * 0.587 + pixel.b * 0.114;
        const useImage = Math.random() < intensity;
        if (useImage) {
          matrix[y][x] = brightness < 0.5;
          colors[y][x] = {
            r: Math.round(Math.max(0, Math.min(1, pixel.r)) * 255),
            g: Math.round(Math.max(0, Math.min(1, pixel.g)) * 255),
            b: Math.round(Math.max(0, Math.min(1, pixel.b)) * 255)
          };
        }
      }
    }
    return { matrix, colors };
  }
  /**
   * Load image data from canvas as RGB values (0-1 range)
   * @private
   */
  async _loadImageDataRGB(canvas, size) {
    const tempCanvas = await this._createCanvas(size, size);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(canvas, 0, 0, size, size);
    const imgData = ctx.getImageData(0, 0, size, size);
    const output = [];
    for (let y = 0; y < size; y++) {
      const row = [];
      for (let x = 0; x < size; x++) {
        const i = (y * size + x) * 4;
        row.push({
          r: imgData.data[i] / 255,
          g: imgData.data[i + 1] / 255,
          b: imgData.data[i + 2] / 255
        });
      }
      output.push(row);
    }
    return output;
  }
  /**
   * Distribute error to neighboring pixels (Floyd-Steinberg)
   * Supports serpentine scanning with leftToRight parameter
   */
  distributeError(imageData, x, y, size, scale, errorR, errorG, errorB, leftToRight = true) {
    const canChange = (px, py) => {
      if (px < 0 || py < 0 || px >= size || py >= size) return false;
      return !isLocked2(size, px, py, scale) && !isData2(px, py, scale);
    };
    const nextX = leftToRight ? x + 1 : x - 1;
    const prevX = leftToRight ? x - 1 : x + 1;
    const a = canChange(nextX, y);
    const b = canChange(prevX, y + 1);
    const c = canChange(x, y + 1);
    const d = canChange(nextX, y + 1);
    const total = (a ? 7 : 0) + (b ? 3 : 0) + (c ? 5 : 0) + (d ? 1 : 0);
    if (total === 0) return;
    if (a) {
      imageData[y][nextX].r += errorR * 7 / total;
      imageData[y][nextX].g += errorG * 7 / total;
      imageData[y][nextX].b += errorB * 7 / total;
    }
    if (b) {
      imageData[y + 1][prevX].r += errorR * 3 / total;
      imageData[y + 1][prevX].g += errorG * 3 / total;
      imageData[y + 1][prevX].b += errorB * 3 / total;
    }
    if (c) {
      imageData[y + 1][x].r += errorR * 5 / total;
      imageData[y + 1][x].g += errorG * 5 / total;
      imageData[y + 1][x].b += errorB * 5 / total;
    }
    if (d) {
      imageData[y + 1][nextX].r += errorR / total;
      imageData[y + 1][nextX].g += errorG / total;
      imageData[y + 1][nextX].b += errorB / total;
    }
  }
  /**
   * Get subpixel overlay data - async version using canvas factory
   * @private
   */
  async _getSubpixelOverlayData(overlayCanvas, subpixelCount, colorMode = "color") {
    const tempCanvas = await this._createCanvas(subpixelCount, subpixelCount);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(overlayCanvas, 0, 0, subpixelCount, subpixelCount);
    const imageData = ctx.getImageData(0, 0, subpixelCount, subpixelCount);
    const data = imageData.data;
    const brightness = [];
    const colors = [];
    for (let row = 0; row < subpixelCount; row++) {
      brightness[row] = [];
      colors[row] = [];
      for (let col = 0; col < subpixelCount; col++) {
        const i = (row * subpixelCount + col) * 4;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const gray = Math.round(r * 0.299 + g * 0.587 + b * 0.114);
        brightness[row][col] = gray / 255;
        if (colorMode === "bw") {
          const bw = gray > 127 ? 255 : 0;
          colors[row][col] = `rgb(${bw},${bw},${bw})`;
        } else if (colorMode === "grayscale") {
          colors[row][col] = `rgb(${gray},${gray},${gray})`;
        } else {
          colors[row][col] = `rgb(${r},${g},${b})`;
        }
      }
    }
    brightness.colors = colors;
    return brightness;
  }
};

// netlify/functions/qr.ts
var nodeCanvasFactory = {
  createCanvas: async (width, height) => {
    return createCanvas(width, height);
  },
  loadImage: async (src) => {
    return loadImage(src);
  }
};
function parseGradientStops(stopsParam) {
  const parts = stopsParam.split(",");
  const stops = [];
  for (let i = 0; i < parts.length - 1; i += 2) {
    const color = `#${parts[i]}`;
    const pos = parseFloat(parts[i + 1]);
    if (!isNaN(pos)) {
      stops.push({ color, pos });
    }
  }
  return stops.length > 0 ? stops : [{ color: "#000000", pos: 0 }, { color: "#000000", pos: 1 }];
}
async function fetchImageAsCanvas(url) {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "ANQR-QR-Generator/1.0"
      }
    });
    if (!response.ok) {
      console.error(`Failed to fetch image: ${response.status} ${response.statusText}`);
      return null;
    }
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const img = await loadImage(buffer);
    const canvas = createCanvas(img.width, img.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    return canvas;
  } catch (error) {
    console.error("Error fetching overlay image:", error);
    return null;
  }
}
var qr_default = async (request) => {
  const url = new URL(request.url);
  const params = url.searchParams;
  const data = params.get("data");
  if (!data) {
    return new Response('Missing required "data" parameter', { status: 400 });
  }
  const size = Math.min(2e3, Math.max(50, parseInt(params.get("size") || "400", 10)));
  const fg = params.get("fg") || "000000";
  const bg = params.get("bg") || "ffffff";
  const ec = params.get("ec")?.toUpperCase() || "H";
  const margin = Math.min(20, Math.max(0, parseInt(params.get("margin") || "4", 10)));
  const transparent = params.get("transparent") === "1";
  const moduleStyle = params.get("style") || "square";
  const finderStyle = params.get("finder") || "square";
  const eyeOuterStyle = params.get("eyeOuter") || finderStyle;
  const eyeInnerStyle = params.get("eyeInner") || finderStyle;
  const eyeScale = Math.min(150, Math.max(50, parseInt(params.get("eyeScale") || "100", 10)));
  const cornerRadius = Math.min(100, Math.max(0, parseInt(params.get("radius") || "0", 10)));
  const moduleGap = Math.min(50, Math.max(0, parseInt(params.get("gap") || "0", 10)));
  const gapMode = params.get("gapMode") || "none";
  const dotRotationDeg = parseInt(params.get("dotRot") || "0", 10);
  const frameStyle = params.get("frame") || "none";
  const frameText = params.get("frameText") ? decodeURIComponent(params.get("frameText")) : "";
  const gradientType = params.get("grad") || "none";
  const gradientAngle = parseInt(params.get("gradAngle") || "0", 10);
  const gradientStopsParam = params.get("gradStops");
  const gradientStops = gradientStopsParam ? parseGradientStops(gradientStopsParam) : void 0;
  const overlayUrl = params.get("img");
  const overlayMode = params.get("mode") || void 0;
  const overlayIntensity = Math.min(100, Math.max(0, parseInt(params.get("intensity") || "100", 10)));
  const colorMode = params.get("colorMode") || "color";
  const logoSize = Math.min(50, Math.max(5, parseInt(params.get("logoSize") || "25", 10)));
  if (!["L", "M", "Q", "H"].includes(ec)) {
    return new Response('Invalid "ec" parameter. Use L, M, Q, or H', { status: 400 });
  }
  const validModuleStyles = ["square", "rounded", "dots", "diamond", "connected"];
  if (!validModuleStyles.includes(moduleStyle)) {
    return new Response(`Invalid "style" parameter. Use one of: ${validModuleStyles.join(", ")}`, { status: 400 });
  }
  try {
    const qrGenerator = new QRGenerator(nodeCanvasFactory);
    const estimatedVersion = qrGenerator.calculateOptimalVersion(decodeURIComponent(data), ec);
    const estimatedModuleCount = estimatedVersion * 4 + 17;
    const moduleSize = Math.max(1, Math.floor((size - margin * 2) / (estimatedModuleCount + margin * 2)));
    const config = {
      content: decodeURIComponent(data),
      typeNumber: 0,
      // Auto-detect
      errorCorrection: ec,
      moduleSize,
      margin,
      fgColor: `#${fg}`,
      bgColor: `#${bg}`,
      transparentBg: transparent,
      moduleStyle,
      finderStyle,
      eyeOuterStyle,
      eyeInnerStyle,
      eyeScale,
      cornerRadius,
      moduleGap,
      gapMode,
      dotRotationDeg,
      frameStyle,
      frameText,
      overlayMode,
      overlayIntensity,
      colorMode,
      logoSize,
      gradient: gradientType !== "none" ? {
        type: gradientType,
        angle: gradientAngle,
        stops: gradientStops
      } : void 0
    };
    let overlayCanvas = null;
    if (overlayUrl && overlayMode) {
      overlayCanvas = await fetchImageAsCanvas(overlayUrl);
    }
    const canvas = await qrGenerator.generate(config, overlayCanvas);
    let outputCanvas = canvas;
    if (canvas.width !== size || canvas.height !== size) {
      outputCanvas = createCanvas(size, size);
      const ctx = outputCanvas.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvas, 0, 0, size, size);
    }
    const pngBuffer = outputCanvas.toBuffer("image/png");
    return new Response(new Uint8Array(pngBuffer), {
      status: 200,
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "public, max-age=31536000, immutable",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("QR generation error:", error);
    return new Response(`Error generating QR code: ${message}`, { status: 500 });
  }
};
export {
  qr_default as default
};
